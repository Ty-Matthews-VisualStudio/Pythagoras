#!requires xlsxwriter

#=========================================================================================================================================================
# Here we define a function that will be visible to the user.  All functions visible to the user must take exactly one argument, which the application will
# use to pass a dictionary object to your function.  The dictionary object contains a small number of keywords that indicate the client version, as well as 
# the files and folders selected by the user.  The dictionary will be described in more detail below in the function 'PrintDictionary'

# To provide a description for your function, include a string entry immediately following the function definition.  This string will be read by the GUI application
# and displayed in the description output window.  You may also specify a more friendly name for your function by surrounding such a name with curly braces {}.
# Python does not allow special characters in the actual function name, so this provides a means to make the name more meaningful outside of Python.  No validation 
# on the friendly name is done, however, so it is up to you to avoid name clashes when using friendly names.
#=========================================================================================================================================================
def HelloWorld(ClientDictionary):
	'{Hello World!}Obligatory first function'
	
	# Any valid Python code can exist here.  Any statements printed to the console (via the print() function) will be displayed to the user on the Output tab 
	# after the script has finished executing.  If your code generates an exception (such as dividing by zero), that output will be displayed on the Error tab.
	print ('Hello world!')	
	return

def PrintDictionary( ClientDictionary ):
	'{Print Dictionary}Prints out the dictionary object sent to the function.'
	
	# The GUI application calls your function and passes a single argument, a dictionary object.  Within that dictionary object are the following keys:
	#
	#	'Version'			The version of the client GUI application.  Will always exist as a string.
	#	'SourceFiles'		A list of files the user has chosen to process.  List may be empty.
	#	'SourceFolders'		A list of folders the user has chosen to process.  List may be empty.
	#	
	# The Version field can be used by your script to execute a specifc set of instructions that might be version-specific.  This can be used to support older clients
	# that might not have updated functionality.  If you do not wish to support older clients, you can simply raise an exception if the version is not one you support, which
	# will terminate the script.
	
	# The 'Source' fields are the primary list objects that your script will loop over to perform actual work.  Both are lists of string objects.  These fields will be
	# demonstrated in proceeding functions.
	
	# This example function takes whatever key/value pairs are in the dictionary object being passed in and prints them to the console.
	for key, value in ClientDictionary.items():
		print( str(key) + '=' + str(value) + '  Type:' + str(type(value)))
	
	# This is the end of the function.  For readability, it is recommended to always end the function body with an empty return statement so that it is clear where the 
	# function truly ends (and not rely on Python's indentation structure to identify the same)	
	return

def SourceFiles(ClientDictionary):
	'{Source Files}Demonstrates working with the files specified by the user'
	
	# Here we are first introduced to importing of external modules (os and time).  Please note that if your script requires use of a non-standard module that does not 
	# come with Python 3.6 or the Pythagoras installation, you should make use of the #!requires syntax to inform the GUI application that additional modules need to be 
	# installed first.  Otherwise, the user will encounter an error when running your script and may not be able to determine how to correct it.  The following modules 
	# are installed as part of the Pythagoras installer: numpy, scipy, and xlsxwriter.
	import os
	import time
	
	# Every file selected by the user for processing is provided in a list named 'SourceFiles' in the dictionary object passed to your function.  The most common
	# use case is to loop over that list and process them individually (as shown below).  For instance, you may extract a specific value from the header and tabulate
	# them into an Excel document.  You might take each file, create a new worksheet in Excel, and then add the raw data to that sheet for graphing purposes.
	
	if(len(ClientDictionary['SourceFiles']) == 0):
		print('No files specified!')
		return
	
	iFileCount = len(ClientDictionary['SourceFiles'])
	print(str(iFileCount) + ' file(s) chosen by user:')
	for sFileName in ClientDictionary['SourceFiles']:
		print( sFileName )
		FileInfo = os.stat(sFileName)
		print('Last modified: ' + time.ctime(FileInfo.st_mtime))
	return
	
def SourceFolders(ClientDictionary):
	'{Source Folders}Demonstrates working with the folders specified by the user'
	
	import os
	
	# As with the SourceFiles() example above, the user may also choose to process folders as well.  In this use case, it is likely that the folder contains a standard set 
	# of files that should always be present, and the parent folder is the container for them.  In this example, we search each chosen folder for the files located in that 
	# folder, and display them to the user.
	
	if(len(ClientDictionary['SourceFolders']) == 0):
		print('No folders specified!')
		return
	
	iFolderCount = len(ClientDictionary['SourceFolders'])
	print(str(iFolderCount) + ' folder(s) chosen by user:')
	for sFolderName in ClientDictionary['SourceFolders']:
		print( 'Files located in ' + sFolderName + ':' )
		
		# Search for all files in the folder, but do not recurse into subdirectories
		for (dirpath, dirnames, filenames) in os.walk(sFolderName):
			for sFileName in filenames:
				print( sFileName )
			break
	return

def Print(ClientDictionary):
	'Example of using the pythagoras.print() functionality.'
	
	# In this example function, we are introduced to the Pythagoras module.  The functionality provided by this module is implemented by the GUI application itself.  
	# You may use this module to interact with the GUI application in a number of ways.  Before we can do any of those things, however, we need to import it.
	import pythagoras
	
	# The pythagoras.print() function differs from the built-in Python print() function in one important way: the output is immediately printed to the GUI application 
	# instead of only at the end.  When your script is executed, any standard output or standard error printing will be trapped by the Pythagoras engine by default.  This
	# output is queued up and then sent to the GUI only after the script has completely finished.  In such a case, the built-in print() function serves as a sort of log of what
	# happened during execution.  If your script involves extensive data processing involving many thousands of files, it might take multiple minutes to complete, and you
	# may wish to provide feedback to the user while the script is executing instead of waiting until the end.  To achieve this, utilize the pythagoras.print() function instead
	# of the Python built-in print() function.  Please be aware that there is a substantial performance loss when using this method, however, as the engine will be invoked 
	# each and every time you execute the pythagoras.print() method.  A good compromise is to utilize the pythagoras.print() method sparingly in lengthy loops to provide 
	# basic status information, and to use the built-in print() method when you intend to output large amounts of information.  If your script will only print information
	#  infrequently, then it is fine to use pythagoras.print() entirely.
	
	# In this tutorial, we explore the differences between the built-in Python print() function and the pythagoras.print() version.
	
	# Here we use the built-in print() function to output some text.  This output will be delayed until the script has finished executing...
	print('Delayed feedback follows:')
	print('--------------------------------------------')
	
	# Now we use the pythagoras.print() functionality.  Note that even though these calls actually come after the print() calls above, the output will show up immediately
	# rather than at the end.
	pythagoras.print('Real-time feedback follows:')
	pythagoras.print('--------------------------------------------')
	
	# Just as a demonstration of the execution cost of these print statements, here we run a loop 100 times, printing each iteration.  Note the order of magnitude difference
	# between the two in terms of execution time.
	
	# The module version of this for-loop takes 2.3 seconds to execute:
	for i in range(0,100):
		pythagoras.print(str(i))
	
	# The Python version of this for-loop takes 0.14 seconds to execute:
	for i in range(0,100):
		print(str(i))
	
	# Finally, here is a simple loop that demonstrates the two methods of providing feedback to the user.  We have a loop that will execute 100 times.  Every 10th iteration
	# we will call to pythagoras.print() to indicate immediately to the user that something is happening.  On every loop, we also use the Python print() statement to accumulate
	# output to display at the very end.
	bDebug = True				# Use a boolean flag to turn debugging statements on/off
	for i in range(0,100):		
		if i % 10 == 0:			# Provide feedback every 10th iteration through the loop 
			pythagoras.print('Loop ' + str(i))
		if bDebug:				# If debugging is enabled, print every loop using the built-in Python method (faster)
			print('Loop ' + str(i))
		
	return

	
def Step(ClientDictionary):
	'Example of using the pythagoras.steprange() and step() functionality to control the GUI progress bar.'
	
	import pythagoras
	import time
	
	# In addition to the real-time feedback afforded via the pythagoras.print() method, there is also the option to control the progress bar that appears within the GUI.
	# Two methods are implemented within the engine for such control: steprange() and step().  The steprange() function takes a single integer argument to specify the 
	# size of the progress bar.  Note that this is an arbitrary definition of size; the actual size of the control on the application does not change.  Rather, this value
	# controls the number of increments to partition the progress bar into.  By default, the progress bar is partitioned into 100 separate blocks.  You step through these
	# blocks by calling the step() function.  Thus, it would take 100 such calls to the step() function for the progress bar to move to completion.  You may specify
	# any range desired by calling steprange(), and then increment through that range by calling step().  A good use-case is to set the range to the number of files
	# that need to be processed multiplied by the number of steps required for each file.  Ideally the processing step for each file would take roughly the same amount of
	# time, such that the progress bar increments smoothly and gradually; however, such precision is not required (and often, not possible to know a priori).  In addition,
	# the progress bar is set to automatically reset back to the zero step if the range is exceeded (e.g. calling step() more than the value set in steprange()).
	
	iNumSteps = 100
	pythagoras.steprange(iNumSteps)
	pythagoras.print('Start of process')
	for i in range(0,iNumSteps):
		pythagoras.step()
		time.sleep(0.25)		# Sleep for 250 ms
	pythagoras.print('End of process')
	
	return
	
def Status(ClientDictionary):
	'Example of using the pythagoras.status() function to change the GUI status bar message.'
	
	import pythagoras
	import time
	
	# In addition to the print() and progress bar and functionality, you may also modify the status bar message via a call to pythagoras.status().  This function
	# takes a single string value and displays it on the status bar, which will appear in the bottom-left corner of the GUI application.  You can use this in place of 
	# pythagoras.print() for information that does not need to be printed to the log.
	
	pythagoras.status('Changing the status here!')
	time.sleep(2)
	for i in range(0,100):
		pythagoras.status('Step ' + str(i))
		time.sleep(0.1)	
	return

def MessageBox( ClientDictionary ):
	'Example of displaying message boxes to the user using pythagoras.messagebox(), requiring them to select an option in order to continue.'
	
	import pythagoras
	
	# The pythagoras.messagebox() function may be called with or without an argument.  If no argument is passed, the GUI application will use default values for all fields.
	# If an argument is passed, it must be a dictionary object containing key/value pairs that describe how the MessageBox should appear.  Each key must be a string.  The value
	# will be either a string or an integer depending on the key being used.
	
	# The (optional) arguments to messagebox() are the following:
	#
	#		Title [string]				The title to display at the top of the message box.  Default is 'Pythagoras'.
	#		Message [string]			The message text to appear inside the dialog box, above the buttons.  Default is 'Message'.
	#		Buttons [integer]			The type of buttons to display (see below).  Default is 0 (OK).
	#		Icon [integer]				The type of icon to display (see below).  Default is no icon.
		
	#		Number		Buttons
	# =================================
	#		0			OK
	#		1			OK and Cancel
	#		2			Abort, Retry, Ignore
	#		3			Yes, No, Cancel
	#		4			Yes and No
	#		5			Retry and Cancel
	#		6			Cancel, Try Again, Continue
	#
	#
	# 		Number		Icon
	# =================================
	#		16			Stop sign
	#		32			Question mark
	#		48			Exclamation point
	#		64			Information circle
	#
	#
	# The 'Buttons' and 'Icon' fields are used to define how the user interacts with the message box and what the possible return values can be.  As an example, say you 
	# wanted to display a stop sign and present the user with Yes/No buttons.  You would specify 4 for the 'Buttons' key of the dictionary object, and a value of 16 for 
	# the 'Icon' dictionary key.
	#
	# Since the default message is the rather vague and meaningless 'Message', it is strongly advised that you specify at least that field in your dictionary object so 
	# that the user has some indication as to why they're seeing a message box appear.
	#
	# Once the user clicks on one of the buttons, the GUI will return an integer value indicating which button was chosen.  You could then use that return value to control
	# execution of your script, or abort entirely.  The values corresponding to various buttons are listed below:
	#
	#		Return Value		Button Chosen
	# =============================================
	#			1					OK
	#			2					Cancel
	#			3					Abort
	#			4					Retry
	#			5					Ignore
	#			6					Yes
	#			7					No
	#			10					Try Again
	#			11					Continue
	
	# This first example will display a question mark (32) and Yes/No buttons (4).  The return value will be either 6 or 7.
	MBDict = {
		'Title' : 'Fromage!',
		'Message' : 'Do you like cheese?',
		'Buttons' : 4,
		'Icon'	: 32
	}
	SelectedOption = pythagoras.messagebox(MBDict)
	if SelectedOption == 6:
		pythagoras.print('You like cheese!')
	else:
		pythagoras.print("You don't like cheese :-(")
	
	# This second example will display a stop sign (16) and OK/Cancel buttons (1).  The default title will be used.  The return value will be either 1 or 2.
	MBDict = {
		'Message' : 'This is an example of the stop sign message box.  Do you want to continue?',
		'Buttons' : 1,
		'Icon'	: 16
	}
	SelectedOption = pythagoras.messagebox(MBDict)
	if SelectedOption == 1:
		pythagoras.print('Continuing with processing....')
	else:
		# Here we raise an exception.  Note that unless you wrap this block of code with a catch statement within your Python script, calling 'raise' will cause the 
		# script to terminate immediately.  No other code will be executed from this point forward.
		raise ValueError('User aborted script')
		
	# This third example will display a message with only the OK button (no icon and default title).  The return value can only be 1.  This may be useful as a way
	# to pause the script and prompt the user to perform some action.
	MBDict = {
		'Message' : 'Press OK.'
	}
	pythagoras.messagebox(MBDict)
	
	return

def SaveFile(ClientDictionary):
	'Example of using the pythagoras.savefile() functionality to prompt the user to specify an output file.'
	
	import pythagoras
	
	# Most often your process is going to create and write to a new file.  The GUI provides a mechanism for prompting the user to specify just such an output file, and
	# also provides a check to ensure that the file can safely be written to.  This is most often a problem with Excel documents that are presently open.  Excel keeps
	# a lock on the file that prevents any other reading/writing of that file, so if your script attempts to write to such a file an exception will be thrown.  The return
	# value from the function is a string containing the full path to the chosen filename, or [None] if the user cancelled the save file dialog box.
	
	# The pythagoras.savefile() function may be called with or without an argument.  If no argument is passed, the GUI application will use default values for all fields.
	# If an argument is passed, it must be a dictionary object containing key/value pairs that describe how the SaveFile dialog box should appear.  Each key must be a string.
	# The (optional) arguments to savefile() are the following:
	#
	#		Title [string]				The title to display at the top of the save file dialog box.  Default is 'Pythagoras'.
	#		Filter [string]				The list of file types to present to the user.  Default is 'All files (*.*)|*.*|'.  At a minimum, you should include this default value
	#									in your custom list, so that the user can choose any available file.  File types are separated by the vertical | character.
	#									An example that specifies Excel XLSX files, comma-delimited CSV files, and 'all files' would be:
	#
	#										'Excel Workbooks (*.xlsx)|*.xlsx|CSV Files (*.csv)|*.csv|All Files (*.*)|*.*|'
	#
	#		DefaultExtension [string]	The default extension to add to the filename if the user does not specify one.  Default is 'csv'.
	#		ReturnIfOpen [boolean]		Set this value to True if you want the GUI to return if the user has chosen a filename that is currently open.  Otherwise, the default
	#									behavior (False) is that the GUI will keep asking the user to specify the file until either: A) the user cancels the dialog box;  
	#									B) the user closes the open file and tries again; or C) the user specifies another filename that is not currently open.
	#
	
	# In this first example, the dictionary object we pass to savefile() has all available options specified.  The return type will be a string specifying the full path to the 
	# file chosen by the user.  Note that calling this function does *not* create the file if it does not already exist; it is up to your script to create the file.
	SFDict = {
		'Title' : 'Please choose the output file',
		'Filter' : 'Text Documents (*.txt)|*.txt|All Files (*.*)|*.*|',
		'DefaultExtension' : 'txt',
		'ReturnIfOpen' : False
	}
	pythagoras.print('Example of savefile() with dictionary argument')
	sFileName = pythagoras.savefile(SFDict)
	if sFileName is not None:
		pythagoras.print('FileName chosen: ' + sFileName)
		
		# Create the file then write some text into it.
		file = open(sFileName,'w') 
		file.write('Hello World') 
		file.close() 
	else:
		pythagoras.print('Savefile() cancelled by user')
	
	# In this second example, we pass no argument to the function and accept all of the default values.
	pythagoras.print('Example of savefile() with default values')
	sFileName = pythagoras.savefile()
	if sFileName is not None:
		pythagoras.print('FileName chosen: ' + sFileName)
		
		# Create the file then write some text into it.
		file = open(sFileName,'w') 
		file.write('Hello World') 
		file.close() 
	else:
		pythagoras.print('Savefile() cancelled by user')
	
	return
	
def OpenFile(ClientDictionary):
	'Example of using the pythagoras.openfile() functionality to open a file.'
	
	import pythagoras
	
	# If after creating an output document, you may wish to have the file open automatically so the user can view it.  The pythagoras module provides an openfile() function
	# to do precisely that.  By "Open", we mean that the file is opened using whatever default application is associated with a specific extension (e.g. Excel for .xlsx documents).
	# This does not refer to opening the file for read/write accesshere in Python.  For that functionality, refer to the Python documentation. 	  It accepts a single string 
	# representing the full path to the file you wish to open.  
	
	# Here we combine multiple components together.  First we prompt the user to specify an output file.  Then we write some data to it.  Finally, we prompt the user if
	# they'd like to open the resulting file.
	
	SFDict = {
		'Title' : 'Please choose the output file',
		'Filter' : 'Text Documents (*.txt)|*.txt|All Files (*.*)|*.*|',
		'DefaultExtension' : 'txt',
		'ReturnIfOpen' : False
	}
	sFileName = pythagoras.savefile(SFDict)
	if sFileName is not None:
		# Create the file then write some text into it.
		file = open(sFileName,'w') 
		file.write('Testing openfile()') 
		file.close() 
		
		MBDict = {
			'Message' : 'Would you like to open the output file?',
			'Buttons' : 4
		}
		SelectedOption = pythagoras.messagebox(MBDict)
		if SelectedOption == 6:
			# Now we open it
			pythagoras.openfile(sFileName)
		
	return
	
def BrowseForFolder(ClientDictionary):
	'Example showing how to prompt the user to specify a folder'
	
	import pythagoras
	
	# In some cases, you may want to only specify a folder to write files into, rather than a specific single file.  The browsefolder() function provides this functionality.
	# The function takes two string parameters: the first is the starting folder (where the browse dialog box starts at) and then a string to use as the title for
	# the dialog box.  You may use this title string to provide more information for the user as to what type of folder they should browsing for.  If the user presses
	# the cancel button, the function will return [None].
	
	# If you wish to retain the last folder chosen by the user and use it as the start folder on subsequent calls to this function, pass a value of 'Registry' for the 
	# first parameter.  This will save the user's most recent selection and use that as the start folder instead.  In this case, the browse dialog box will start at
	# the user's "Computer" icon.
	
	# In both cases (1: setting a manual start folder; and 2: using the registry), if the starting folder cannot be found (because it was deleted or renamed) then the
	# browse dialog box will start at the "Computer" icon.
	sBaseFolder = pythagoras.browsefolder( r'C:\Temp','Please choose the base folder')
	if sBaseFolder is None:
		print('User canceled browse for folder')
		return
	else:
		print('Folder chosen: ' + sBaseFolder)
	
	# Here is an example for saving the folder chosen into the registry.  Every subsequent call using 'Registry' will preset the browse dialog box to the previously chosen directory.
	sBaseFolder = pythagoras.browsefolder( 'Registry','Please choose the base folder (registry saved)')
	if sBaseFolder is None:
		print('User canceled browse for folder')
		return
	else:
		print('Folder chosen: ' + sBaseFolder + ' (saved to registry)')
	return

def Clipboard(ClientDictionary):
	'Example of getting and putting strings to the clipboard'
	import pythagoras
	
	# To interact with the clipboard, the pythagoras module includes a clipboard() function that takes a dictionary object which describes the action to be taken and the
	# data to place on the clipboard.  Two actions are possible: 'Put' and 'Get'.  The first action will place the contents of the 'Data' value onto the clipboard, whereas
	# the second action will retrieve the contents of the clipboard and return it as a string.
	ClipboardDictionary = {
		'Action':'Put',
		'Data':'Hello clipboard from Pythagoras!'
	}
	pythagoras.clipboard(ClipboardDictionary)
	
	
	ClipboardDictionary['Action'] = 'Get'
	sText = pythagoras.clipboard(ClipboardDictionary)
	
	print('Data copied from clipboard: ' + sText)
		
	return

def DisplayForm(ClientDictionary):
    '{Display Form}Example of using the pythagoras.displayform() functionality to build an HTML form for the user to fill out and submit.'
	
    import pythagoras
	
	# So far we have used a number of pythagoras built-in functions to interact with the user and retrieve information.  While a lot can be done using Message box
	# functionality, at some point we need to be able to have the user enter arbitrary text that can be used in our script.  For example, you may want to provide a way
	# for the user to specify the surface area of your material.  Or you may want to select the type of experiment that was run from a list of 10 different experiments.
	# It would be more elegant to have a single form with checkboxes, text boxes, or combo boxes to indicate user preferences instead.  This is where the displayform() 
	# function comes in.  A form is a collection of input fields that we present to the user to fill out all at once.  These fields may be free-form text fields 
	# (e.g. a description), a choice from a number of options (combo box), or a checkbox to indicate boolean yes/no.
	
	# A Python context manager class is available to generate an input form and display it to the user.  You can create such a form with the following code:
	
	#		with PythagorasDisplayForm() as MyInputForm:
	
	# You may then call methods on the returned object to add fields to the form or set the form's properties.  The fields are themselves class objects which have methods for 
	# setting their properties.  The form has a number of properties which will change its appearance:
	#
	#		with PythagorasDisplayForm() as MyInputForm:
	#			MyInputForm.SetBGColor('#ccffcc')
	#			MyInputForm.SetWidth(500)
	#			MyInputForm.SetHeight(500)	
	#
	# In the above example, three methods were introduced that change the input form's appearance.  The first, SetBGColor(), takes a string parameter that will set the 
	# background color of the HTML form.  For examples of what value to pass to this function, please visit https://www.w3schools.com/tags/att_body_bgcolor.asp
	# The second and third methods are used to set the form's width and height (in pixels).
	
	# The client GUI utilizes a template document to render the form.  The template is just an HTML document with a number of special HTML tags that can be 
    # utilized to change its appearance.  The default template is named 'DefaultTemplate.html' and is located in the 'Common' sub-folder.  If you'd like to specify your 
    # own template file, you may call the SetTemplate() function to override the default behavior:
    
    
    #		with PythagorasDisplayForm() as MyInputForm:
	#			MyInputForm.SetBGColor('#ccffcc')
	#			MyInputForm.SetWidth(500)
	#			MyInputForm.SetHeight(500)	
    #			MyInputForm.SetTemplate(r'c:\MyPath\MyTemplate.html')	

    
    # Please note, however, that any local paths unique to your computer will not be accessible to other users who might want to use your Python script.  
    # There are some folders which would be common between users, specifically the 'MyDocuments\Pythagoras' structure which would be created by default when the application
    # is first executed.  Since every user has a different "MyDocuments" path that includes their username, you will want to either specify a common shared folder 
    # (e.g. Q:\Common\General...) or specify a local path using special keyword strings so that the client application will be able to find the template.  These keyword 
    # strings only apply to the SetTemplate() function of the display form.  The following substrings can be used to specify the corresponding path on the user's computer:
	
	#	<local_scripts_dir>	:	The user's specified local scripts folder.  By default, this is 'MyDocuments\Pythagoras\Scripts\Local', but can be changed by the user.
    #	<common_scripts_dir>:	The user's specified common scripts folder.  By default, this is 'MyDocuments\Pythagoras\Scripts\Common', but can be changed by the user.
	#	<app_dir>			:	The folder where the GUI application's EXE file is located
	#	<working_dir>		:	The current working directory of the GUI application
	#
	# So as an example, if you have your custom HTML template located in "MyDocuments\Pythagoras\Templates\Local\", you can specify that full path with the following code:
	#
	#		with PythagorasDisplayForm() as MyInputForm:
	#			MyInputForm.SetTemplate(r'<local_scripts_dir>\MyTemplate.html')
	#
    # It is recommended as a best practice to place any custom HTML template into a shared folder structure that every user of your custom script will have access to.  This 
    # would typically be something like a shared network drive.  If there is no common network drive shared between all users, you will want to send out your template file
    # to all users and instruct them to save the file into one of the special keyword strings listed above. 

    
	# Within the DefaultTemplate.html template are a number of special tags that can be directly replaced by your function.  The intent of these tags is to change the content of
	# the HTML page so as to provide helpful information to the user.  Three such tags are present in the template:
	#
	#		<!--Title-->
	#		<!--Default_Style-->
	#		<!--Summary-->
	#
	# The <!--Title--> tag can be replaced with a text string that will change the title of the form.  The <!--Default_Style--> tag can be used to change the font type, color,
	# size, etc.  The <!--Summary--> tag appears at the bottom of the form and can be used to write a wall of text that appears below all of the input variables.  Since
	# these three tags are present in the default HTML template, there are input form class methods for each:
	#
	#		SetTitle(Title)					Each method takes exactly one string
	#		SetSummary(Summary)				
	#		SetDefaultStyle(Style)
	#
	# If you choose to make your own custom HTML template, and would like to create new special HTML tags, you may use the following method to set its replaced value:
	#
	#		SetReplaceString('<!--Tag-->','Value')
	#
	# Finally, we can call Display() to generate the input form and display it to the user.  In this example we are not providing any fields, so the form will be rather
	# uninteresting.  Each of the different fields (text, checkbox, and combobox) will be discussed in proceeding example functions.  The Display() function will 
	# return a boolean True/False value based on whether the user cancelled the input form (False) or accepted the input form by clicking OK (True).
	
    with PythagorasDisplayForm() as MyInputForm:
        MyInputForm.SetBGColor('#ccffcc')		# Light green color
        MyInputForm.SetWidth(500)
        MyInputForm.SetHeight(500)
        MyInputForm.SetTemplate(r'<common_scripts_dir>\DefaultTemplate.html')
        MyInputForm.SetTitle('Display Form')
        MyInputForm.SetSummary('Summary')
        MyInputForm.Display()
	
    return

#=========================================================================================================================================================
# Example code for using the 'CheckBox' input type for displayform().  Presents a checkbox to the user and then prints out the results to the console.
#=========================================================================================================================================================
def CheckBox( ClientDictionary ):
	'Demonstrates the use of the CheckBox input type for displayform().'
	import pythagoras
	
	with PythagorasDisplayForm() as MyInputForm:		
		MyInputForm.SetBGColor('Red')
		MyInputForm.SetTitle('Do you like cheese?')		
		MyInputForm.SetDefaultStyle('font-family:Helvetica;font-size:20;color:yellow')
		
		MyCheckBox = MyInputForm.AddCheckBox('Cheese','I like cheese')
		# Here we added a CheckBox variable named 'Cheese' to our input form.  All functions to add a variable to the form, regardless of their type, require a name
		# and a description.  The name is the first parameter to the function and the description second.  The AddCheckBox() function will return a class object that 
		# represents that new input variable.  Further modification to the variable can only be done using the returned class object.  The class object supports the 
		# following methods for all variable types:
		
		#		SetDescription(string)			Sets the description to the variable parameter
		#		SetDefault(value)				Sets the default value (checked or not in the case of a CheckBox).  Parameter type depends on variable type.
		#		SetRegistry(True/False)			Sets whether the default value will come from the Registry (True) or from a call to SetDefault() (False)
		#		GetValue()						Returns the value entered or chosen by the user after a call to Display().  Returns None if Display() has not been called.
		#
		
		MyCheckBox.SetDefault(True)
		# Since we are working with a CheckBox input type, the expected values will be boolean True/False.  We want the checkbox to be selected by default, so we passed
		# True to the SetDefault() method.  Note that this default value only applies to the very first time the input form is displayed to a given user.  After that,
		# the default value will come from the user's registry.  In this way, the input form will remember the last values that were entered by the user.  You may
		# wish to override this behavior and force the default value to be a specific value.  In this case, call SetRegistry(False) on the class object before calling
		# Display() on the input form.
		
		if not MyInputForm.Display():
			print ('User cancelled input form')
			return
		# Here we check the return value to our call to Display().  If the method returns False, the user cancelled the input form and we should abort our script.  Otherwise,
		# we are okay to continue processing.  Note that the engine will never abort your script based on what the user has input or selected; it is up to your script to
		# decide how to handle such events.
		
		# There are two ways to retrieve the value of our input variable now that the user has clicked OK on the input form.  We may either call GetValue() using the class
		# object for the variable, or we can call GetValue(VariableName) on the input form class object.  Both ways are demonstrated below:
		CheeseValue = MyCheckBox.GetValue()
		CheeseValue = MyInputForm.GetValue('Cheese')
	
		if CheeseValue:
			print('You like cheese :-)')
		else:
			print("You don't like cheese :-(")
		
	return
	
#=========================================================================================================================================================
# Example code for using the 'ComboBox' input type for displayform().  Presents a combobox with options to the user and then prints out the selected item to the console.
#=========================================================================================================================================================
def ComboBox( ClientDictionary ):
	'Demonstrates the use of the ComboBox input type for displayform().'
	
	import pythagoras
	import string
	
	with PythagorasDisplayForm() as MyInputForm:
		MyInputForm.SetBGColor('Cyan')
		MyInputForm.SetTitle('What are your favorites?')		
		MyInputForm.SetDefaultStyle('font-family:Helvetica;font-size:18;color:black')
		
		CBColor = MyInputForm.AddComboBox('Color','Favorite color:')
		CBDay = MyInputForm.AddComboBox('Day','Favorite day:')
		CBHex = MyInputForm.AddComboBox('Hex','Favorite hexadecimal character:')
		# Here we added three different combo boxes to our input form.  A combo box is unique among the various input variables in that it requires further details
		# in order to be used properly.  Specifically, we must specify the various entries that will go into the combo box for the user to choose from, and the 
		# corresponding value we expect to get back once they do.  This is done using the AddEntry() method of the returned class object:
		
		CBColor.AddEntry(0,'Red')
		CBColor.AddEntry(1,'Green')
		CBColor.AddEntry(2,'Blue')
		CBColor.AddEntry(3,'Yellow')
		
		# Note the AddEntry() method requires two parameters: the first specifies the value that will be given to the corresponding input variable once the user has
		# accepted the input form.  The second parameter is the description to present to the user corresponding to that value.  These two can be different or the same.  
		# Both value and description can be either numeric or a string.  As with all input variables, the ComboBox type uses SetDefault() to specify which option should 
		# be selected first.
		CBColor.SetDefault(1)
		
		CBDay.AddEntry('Sun','Sunday')
		CBDay.AddEntry('Mon','Monday')
		CBDay.AddEntry('Tue','Tuesday')
		CBDay.AddEntry('Wed','Wednesday')
		CBDay.AddEntry('Thr','Thursday')
		CBDay.AddEntry('Fri','Friday')
		CBDay.AddEntry('Sat','Saturday')
		CBDay.SetDefault('Sat')
		
		for digit in string.digits:
			CBHex.AddEntry(digit,digit)
		for char in 'ABCDEF':
			CBHex.AddEntry(char,char)
		CBHex.SetDefault(0)
		
		if not MyInputForm.Display():
			print ('User cancelled input form')
			return
		
		Color = CBColor.GetValue()
		Day = CBDay.GetValue()
		Hex = CBHex.GetValue()
	
		print('Color:' + str(Color))				# str() is required since the 'Color' variable keys are numeric
		print('Day:' + Day)
		print('Hex:' + str(Hex))					# str() is required since the 'Hex' variable keys might be either string or numeric
	
	return 

#=========================================================================================================================================================
# Example code for using the 'Text' input type for displayform().  Presents an edit box where the user can specify any arbitrary text.
#=========================================================================================================================================================
def Text( ClientDictionary ):
	'Demonstrates the use of the Text input type for displayform().'
	
	import pythagoras
	import string
	import datetime
		
	# The last example is the text type.  This type of variable will be shown as an edit box in which the user can type any arbitrary text.  No validation of the 
	# actual data is performed. 
	with PythagorasDisplayForm() as MyInputForm:
		MyInputForm.SetBGColor('#dddddd')
		MyInputForm.SetTitle('Various text input fields')		
		MyInputForm.SetDefaultStyle('font-family:Helvetica;font-size:18;color:black')
		
		TXTTitle = MyInputForm.AddText('Title','Please enter a title:')
		TXTPassword = MyInputForm.AddText('Password','Password field:')
		TXTSheetName = MyInputForm.AddText('SheetName','Excel sheet name:')
		TXTHidden = MyInputForm.AddText('Hidden','Date of last execution')
		
		# If you wish to limit the length of what can be entered (for example, the name of an Excel worksheet can be a maximum of 30 characters), then use the
		# SetMaxLength() method of the class object, with an integral value for the length:
		TXTSheetName.SetDefault('Sheet1')
		TXTSheetName.SetMaxLength(30)

		# If you wish to block out the value being entered by the user, call SetPassword(True) on the class object.  Note that even though the data entered into a 
		# Password type will not be visible to the user, the value is not encrypted in any way and will still be visible to the Python script in plain text format.
		TXTPassword.SetPassword(True)
		
		# It is possible to create hidden input fields that will not be displayed to the user.  These can be used to store information about the execution of your
		# function without prompting the user for input.  For example, here we are storing the current date into a hidden field.  We can later look at this date
		# to see when the last time our function was called.  This provides a way of persisting some data without involving interaction from the user.  As another 
		# example, we can use a hidden field to check to see whether the script has ever been executed.  This would require the use of GetRegistryValues(), which
		# is explained below.
		TXTHidden.SetHidden(True)
		TXTHidden.SetDefault(datetime.date.today().strftime('%Y-%m-%d'))
	
		if not MyInputForm.Display():
			print ('User cancelled input form')
			return
		
		print('Title:' + TXTTitle.GetValue())
		print('Password:' + TXTPassword.GetValue())
		print('SheetName:' + TXTSheetName.GetValue())
		print('Hidden:' + TXTHidden.GetValue())
	
	
	return

#=========================================================================================================================================================
# Example code for using the 'Text' input type for displayform().  Presents an edit box where the user can specify any arbitrary text, then performs validation
# on the resulting value if the user accepts the form.
#=========================================================================================================================================================
def TextValidate( ClientDictionary ):
	'Demonstrates the use of the Text input type for displayform() with data validation.'
	
	import pythagoras
	
	bValid = False
	fSurfaceArea = 0.0
	with PythagorasDisplayForm() as MyInputForm:
		MyInputForm.SetBGColor('#dddddd')
		MyInputForm.SetDefaultStyle('font-family:Helvetica;font-size:18;color:black')
		TXTSurfaceArea = MyInputForm.AddText('SurfaceArea','Surface area (cm<sup>2</sup>):')
		TXTSurfaceArea.SetDefault('-1.0')
		TXTSurfaceArea.SetRegistry(False)
		# Just to demonstrate the use of the 'Registry' function, here we specify that the default value should not come from the registry but rather the value 
		# specified by SetDefault()
		while not bValid:
			if not MyInputForm.Display():
				print ('User cancelled input form')
				return
	
			bValid = True
			fSurfaceArea = float(TXTSurfaceArea.GetValue())
			if fSurfaceArea < 0.0 or fSurfaceArea >= 100.0:
				bValid = False
				pythagoras.messagebox({'Message' : 'Surface area must be a positive number less than 100.'})

	print('SurfaceArea = ' + str(fSurfaceArea))
	return
	

	
def GetRegistryValues(ClientDictionary):
	'{Get Registry Values}Demonstrates the use of GetRegistryValues() on a form to retrieve values from the registry without displaying the form.'
	import pythagoras
	
	# There may be occasions where you do not wish to present a form to the user in all instances.  At the same time, you would like
	# to retrieve values that the user had chosen previously.  Typically the default values that appear in a form are retrieved from the 
	# user's registry database in Windows prior to the form being displayed.  To retrieve the values without displaying the form, you must
	# first create the input fields as normal and then call GetRegistryValues() on the form.  This functionality was introduced in 
	# version 1.1 of the desktop application, so it is important to validate that the user is running at least that version.
	
	# Note that you needn't fully specify the form variables in order to retrieve them from the registry.  The variable name is all that is
	# required.  That said, there is one important caveat when working with combo box values.  The entries for a combo box can have either 
	# numeric or character default values.  Their value is always stored in the registry as a string, however.  As such, if you do not 
	# specify the list of entries for a combo box when calling GetRegistryValues(), the function will always return a string value regardless
	# of how it was initially defined.  It is advised to always convert the return value for a combo box into the desired data type to avoid
	# any potential conversion issue.
	
	SelectedOption = pythagoras.messagebox({'Title' : 'Display form?','Message' : 'Do you want to set plotting attributes?','Buttons' : 4 })
	with PythagorasDisplayForm() as MyInputForm:
		XFont = MyInputForm.AddComboBox('XFont','X-Axis font:')
		XFont.SetDefault('Arial')
		XFont.AddEntry('Arial','Arial')
		XFont.AddEntry('Helvetica','Helvetica')
		XFont.AddEntry('Times New Roman','Times New Roman')
		XFont.AddEntry('Courier New','Courier New')
		
		XSize = MyInputForm.AddText('XSize','X-Axis font size:')
		XSize.SetDefault('12')
		
		YFont = MyInputForm.AddComboBox('YFont','Y-Axis font:')
		YFont.SetDefault('Arial')
		YFont.AddEntry('Arial','Arial')
		YFont.AddEntry('Helvetica','Helvetica')
		YFont.AddEntry('Times New Roman','Times New Roman')
		YFont.AddEntry('Courier New','Courier New')
		
		YSize = MyInputForm.AddText('YSize','Y-Axis font size:')
		YSize.SetDefault('12')
		
		if SelectedOption == 7 and float(ClientDictionary['Version']) >= 1.1:
			# Just get whatever was last used
			MyInputForm.GetRegistryValues()
		else:
			# Display the form to get updated data
			MyInputForm.Display()
			
		# Now we can do something with the values
		XFont.GetValue()
		XSize.GetValue()
	
	return

#=========================================================================================================================================================
# Example code for creating Excel spreadsheets.  This puts together a number of concepts outlined above.  For more details on the xlsxwriter library, visit:
#
#				http://xlsxwriter.readthedocs.io/
#
#=========================================================================================================================================================
def CreateXLSX( ClientDictionary ):
	'{Create XLSX document}Demonstrates how to create an XLSX document and populate it with values.'
	
	import pythagoras
	import xlsxwriter
	from xlsxwriter.utility import xl_rowcol_to_cell
	import random	
	
	with PythagorasDisplayForm() as MyInputForm:
		# Create a text field that we'll use to create the sheet
		TXTSheetName = MyInputForm.AddText('SheetName','Excel sheet name:')
		TXTSheetName.SetDefault('MySheet')
		TXTSheetName.SetMaxLength(30)
			
		CBOpenFiles = MyInputForm.AddCheckBox('OpenFile','Open file after processing')
		CBOpenFiles.SetDefault(True)
		
		if not MyInputForm.Display():
			print('User cancelled form')
			return		
	
		SFDict = {
			'Title' : 'Please choose the output file',
			'Filter' : 'Excel Workbooks (*.xlsx)|*.xlsx|All Files (*.*)|*.*|',
			'DefaultExtension' : 'xlsx',
			'ReturnIfOpen' : False
		}	
		
		sFileName = pythagoras.savefile(SFDict)
		if sFileName is None:
			print('User cancelled savefile()')
			return	

		# This first call will create the file
		WorkBook = xlsxwriter.Workbook(sFileName, {'strings_to_numbers': True})
		
		# Remove invalid characters for sheet names in Excel
		SheetName = TXTSheetName.GetValue()
		SheetName = SheetName.translate({ord(c): None for c in "'[]:*?/\\"})  
		
		# Add the worksheet to our workbook
		WorkSheet = WorkBook.add_worksheet(SheetName)
		WorkSheet.set_column(0, 3, 15)			 		# Set the column width		
		WorkSheet.write( 0, 0, 'Value A' )				# First argument is the row number, second argument is the column (both zero-indexed)
		WorkSheet.write( 0, 1, 'Value B' )
		WorkSheet.write( 0, 2, 'Value C' )
		WorkSheet.write( 0, 3, 'Value D' )	
		WorkSheet.write( 0, 4, 'Average' )
		WorkSheet.write( 0, 5, 'Std Dev' )
		
		# Just output some random data
		for i in range(0,10):
			Row = i + 1
			WorkSheet.write( Row, 0, random.uniform(0.0, 10.0))
			WorkSheet.write( Row, 1, random.uniform(0.0, 10.0))
			WorkSheet.write( Row, 2, random.uniform(0.0, 10.0))
			WorkSheet.write( Row, 3, random.uniform(0.0, 10.0))
			
			# You can use any Excel formula in your cells:
			WorkSheet.write( Row, 4, '=AVERAGE(' + xl_rowcol_to_cell(Row,0) + ':' + xl_rowcol_to_cell(Row,3) + ')' )
			WorkSheet.write( Row, 5, '=STDEV(' + xl_rowcol_to_cell(Row,0) + ':' + xl_rowcol_to_cell(Row,3) + ')' )
		
		WorkBook.close()
		
		# Only open after the workbook has been closed
		if CBOpenFiles.GetValue():
			pythagoras.openfile(sFileName)
		
	return 

#=========================================================================================================================================================
# Example code for creating Excel spreadsheets with charts.  This puts together a number of concepts outlined above.  For more details on the xlsxwriter library, visit:
#
#				http://xlsxwriter.readthedocs.io/
#
#=========================================================================================================================================================
def CreateXLSXScatterPlot( ClientDictionary ):
	'{Create XLSX scatter plot}Demonstrates how to create an XLSX document, populate it with random values, and then make a scatter plot of those values'
	
	import pythagoras
	import xlsxwriter
	from xlsxwriter.utility import xl_rowcol_to_cell
	import random

	# Start with our boilerplate displayform() dictionary
	with PythagorasDisplayForm() as MyInputForm:
		# Create a text field that we'll use to create the sheet
		TXTSheetName = MyInputForm.AddText('SheetName','Excel sheet name:')
		TXTSheetName.SetDefault('MySheet')
		TXTSheetName.SetMaxLength(30)
		
		TXTNumPoints = MyInputForm.AddText('NumDataPoints','Number of data points:')
		TXTNumPoints.SetDefault('100')
		TXTNumPoints.SetMaxLength(4)
			
		CBOpenFiles = MyInputForm.AddCheckBox('OpenFile','Open file after processing')
		CBOpenFiles.SetDefault(True)
		
		bValid = False
		NumDataPoints = 100
		while not bValid:
			if not MyInputForm.Display():
				print('User cancelled form')
				return
			
			bValid = True
			NumDataPoints = int(TXTNumPoints.GetValue())
			if NumDataPoints < 1 or NumDataPoints > 1000:
				bValid = False
				pythagoras.messagebox({'Message' : 'Number of data points must be between 1 and 1000.'})
				TXTNumPoints.SetRegistry(False)
		
		SFDict = {
			'Title' : 'Please choose the output file',
			'Filter' : 'Excel Workbooks (*.xlsx)|*.xlsx|All Files (*.*)|*.*|',
			'DefaultExtension' : 'xlsx',
			'ReturnIfOpen' : False
		}
		
		sFileName = pythagoras.savefile(SFDict)
		if sFileName is None:
			print('User cancelled savefile()')
			return	
		
		WorkBook = xlsxwriter.Workbook(sFileName, {'strings_to_numbers': True})
	
		# Remove invalid characters for sheet names in Excel
		SheetName = TXTSheetName.GetValue()
		SheetName = SheetName.translate({ord(c): None for c in "'[]:*?/\\"})  
		
		WorkSheet = WorkBook.add_worksheet(SheetName)
		WorkSheet.set_column(0, 3, 15)			 		# Set the column width		
		WorkSheet.write( 0, 0, 'Name:' )
		WorkSheet.write( 0, 1, 'Random data' )
		WorkSheet.write( 1, 0, 'X' )				# First argument is the row number, second argument is the column (both zero-indexed)
		WorkSheet.write( 1, 1, 'Y' )
		StartOfData = 2
		
		MinValue = 0.0
		MaxValue = 10.0
		
		# First add a chartsheet to store the chart, then add the actual chart
		ChartSheet = WorkBook.add_chartsheet( 'Scatter Plot' )
		Chart = WorkBook.add_chart({'type': 'scatter'})
		ChartSheet.set_chart( Chart )
		Chart.set_x_axis({
			'name': 'X',
			'name_font': {
				'name': 'Arial',
				'size' : 12
			},
			'num_font': {
				'name': 'Arial',
				'size' : 12
			},
			'major_gridlines': {
				'visible': False
			},
			'crossing': 0.0,
			'min':MinValue,
			'max':MaxValue,
			'major_tick_mark': 'cross',
			'minor_tick_mark': 'outside'
		})

		Chart.set_y_axis({
			'name': 'Y',
			'name_font': {
				'name': 'Arial',
				'size' : 12
			},
			'num_font': {
				'name': 'Arial',
				'size' : 12
			},
			'major_gridlines': {
				'visible': False
			},		
			'crossing': 0.0,
			'min':MinValue,
			'max':MaxValue,
			'major_tick_mark': 'cross',
			'minor_tick_mark': 'outside'
		})
		
		for i in range(0,NumDataPoints):
			Row = i + StartOfData
			WorkSheet.write( Row, 0, random.uniform(MinValue, MaxValue))
			WorkSheet.write( Row, 1, random.uniform(MinValue, MaxValue))
			
			# You can use any Excel formula in your cells:
			WorkSheet.write( Row, 2, '=AVERAGE(' + xl_rowcol_to_cell(Row,0) + ':' + xl_rowcol_to_cell(Row,1) + ')' )
			WorkSheet.write( Row, 3, '=STDEV(' + xl_rowcol_to_cell(Row,0) + ':' + xl_rowcol_to_cell(Row,1) + ')' )
		
		Chart.add_series({
			'name':       [SheetName, 0, 1],
			'categories': [SheetName, StartOfData, 0, StartOfData + NumDataPoints, 0],
			'values':     [SheetName, StartOfData, 1, StartOfData + NumDataPoints, 1],
			'marker':	{	'type': 'circle','size':7,
							'border':{'color':'red'},
							'fill':{'color':'red'}}
						})
		WorkBook.close()
		
		# Only open after the workbook has been closed
		if CBOpenFiles.GetValue():
			pythagoras.openfile(sFileName)
		
	return
