
# This is some boilerplate code to get your new script off the ground.  Feel free to modify as necessary!  For help and code samples, please check out the tutorial script
# located in the root of your Local Scripts folder.  This boilerplate code creates an input form and displays it to the user.

def MyFunction(ClientDictionary):
	# The text between curly braces {} will be used as the friendly display name instead of the literal function name.  Such text will then be removed from the description
	'{Friendly Function Name}Enter a description of your function here'
	
	with PythagorasDisplayForm() as MyInputForm:
		MyInputForm.SetBGColor('#ccffcc')		# Light green color
		MyInputForm.SetDefaultStyle('font-family:Helvetica;font-size:16;color:black')
		MyInputForm.SetWidth(500)
		MyInputForm.SetHeight(500)
		MyInputForm.SetTitle('MyFunction')
		
		# Add a checkbox
		MyCheckBox = MyInputForm.AddCheckBox('CheckBox','CheckBox')
		
		# Add a combobox
		MyComboBox = MyInputForm.AddComboBox('ComboBox','ComboBox:')
		for i in range(0,10):
			MyComboBox.AddEntry(i,'Option ' + str(i + 1))
		
		# Add a text box
		MyText = MyInputForm.AddText('Text','Text:')
		MyText.SetDefault('Default text')
		
		# Call Display() to display the form and get input from the user.  Note the function will return True/False depending on whether the user clicked OK/Cancel.
		if not MyInputForm.Display():
			print ('User cancelled input form')
			return
		
		# We can now retrieve values chosen by the user.
		print('CheckBox:' + str(MyCheckBox.GetValue()))
		print('ComboBox:' + str(MyComboBox.GetValue()))
		print('Text:' + str(MyText.GetValue()))
	
	# These sections of code will run only if some files or folders have been chosen for processing.
	if len(ClientDictionary['SourceFiles']) > 0:
		print('List of files to be processed:')
		for FileName in ClientDictionary['SourceFiles']:
			print( FileName )
	else:
		print('No files to be processed')
	
	if len(ClientDictionary['SourceFolders']) > 0:
		print('List of folders to be processed:')
		for FolderName in ClientDictionary['SourceFolders']:
			print( FolderName )
	else:
		print('No folders to be processed')
		
	# Here we demonstrate how to open a CSV file and parse its contents
	import urllib.request
	import shutil
	import os
		
	# This first part is just downloading a file with some data in it from the web; you will not need this section of code just to open local CSV files
	url = 'https://data.lacity.org/api/views/nxs9-385f/rows.csv?accessType=DOWNLOAD'	# This is the 2010 Census data for the city of Los Angeles
	filename = os.environ['TEMP'] + '\\census.csv'
	with urllib.request.urlopen(url) as response, open(filename, 'wb') as out_file:
		shutil.copyfileobj(response, out_file)
		
	# Here are the vital bits for opening CSV files
	import codecs
	import csv
	
	# Open the file
	with codecs.open( filename,'r','utf-8-sig') as csvfile:
	
		# Handle data stream as a CSV reader
		reader = csv.reader( csvfile, delimiter=',')
		
		# Loop through each row in the file
		rownum = 1
		maxpop = 0
		maxpopzipcode = 0
		indexes = dict()
		
		# Header row for this CSV file looks like the following:
		# Zip Code,Total Population,Median Age,Total Males,Total Females,Total Households,Average Household Size
		for row in reader:
			if rownum == 1:
				# Parse the first row into a dictionary object so we can use names to refer to the columns instead of numbers (protects us in case the column order changes)
				for field,index in zip(row,range(0,len(row))):
					indexes[field] = index
			
			if rownum > 1:
				# Find the zip code with the largest population
				pop = int(row[indexes['Total Population']])
				zipcode = int(row[indexes['Zip Code']])
				if pop > maxpop:
					maxpop = pop
					maxpopzipcode = zipcode
					
				# How many people live in Beverly Hills?				
				if zipcode == 90210:
					print(str(pop) + ' people live in Beverly Hills, zip code 90210')
			
			rownum += 1
	
	print('The zip code with the largest population (' + str(maxpop) + ') was ' + str(maxpopzipcode) )
	return