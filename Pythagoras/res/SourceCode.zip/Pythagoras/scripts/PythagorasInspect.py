import ast
import sys
import py_compile
import inspect 
import re

def _PythagorasTopLevelFunctions(body):
	return (f for f in body if isinstance(f, ast.FunctionDef))

def _PythagorasParseAST(filename):
	with open(filename, "rt") as file:
		return ast.parse(file.read(), filename=filename)
		
def _PythagorasInspect( Dict ):
	class writer(object):
		log = []

		def write(self, data):
			self.log.append(data)
		
		def flush(self):
			del self.log[:]
			
		def has_error(self):
			if len(self.log) > 0:
				return True
			return False

	logger = writer()
	temperr = sys.stderr
	sys.stderr = logger
	
	version = None
	ret = []
	for k,v in Dict.items():
		key = str(k)
		if key == 'Version':
			version = v
			continue
		py_compile.compile(v)
		if logger.has_error():
			if version is not None:
				if version == '1.0':
					ret.append( key + '|raise|' + logger.log[0] + '|' )
				else:
					ret.append( key + '|raise|' + logger.log[0] )
			logger.flush()
		else:
			tree = _PythagorasParseAST(v)
			for func in _PythagorasTopLevelFunctions(tree.body):
				if(func.name[0] != '_'):
					docs = ast.get_docstring(func)
					displayname = func.name
					
					if str(docs).find('|') != -1:
						ret.append( key + '|raise|Description string in function "' + func.name + '" contains pipe symbols.|' )
						continue
					
					# Search for {abc} in the docs string, remove it if found
					if docs is not None:
						regex = re.search(r'\{(.*?)\}',docs)
						if regex is not None:
							displayname = regex.group(1)
							docs = docs.replace('{'+displayname+'}','')
					else:
						docs = ''
					
					# If no version key is present, use the default 3-string split by |
					descriptor = key + '|' + func.name + '|' + str(docs)
					if version is not None:
						if version == '1.0':
							# This was added in version 1.0.2 of the GUI 
							descriptor = key + '|' + func.name + '|' + str(docs) + '|' + displayname
					ret.append( descriptor )
	sys.stderr = temperr
	return ret

if __name__ == "__main__":
	dict = {}
	for index,filename in zip(range(0,len(sys.argv[1:])), sys.argv[1:]):
		key = str(index)
		value = filename
		dict[key] = value
	ret = _PythagorasInspect(dict)
	print (ret)
	
