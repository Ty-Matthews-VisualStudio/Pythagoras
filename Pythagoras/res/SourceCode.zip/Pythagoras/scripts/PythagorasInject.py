import sys, traceback, contextlib
import io, os
import pythagoras

class PythagorasDatabaseEntry(object):
	def __init__(self):
		self.m_FileName = ''
		self.m_Tags = []
	
	def __enter__(self):
		self.m_FileName = ''
		self.m_Tags = []
		return self
		
	def __exit__(self, *args):
		SaveDict = dict()
		SaveDict['FileName'] = self.m_FileName
		SaveDict['Tags'] = self.m_Tags
		pythagoras.DatabaseCreateEntry(SaveDict)
		return
	
	def SetFileName(self,sFileName):
		self.m_FileName = sFileName 
	
	def AddTag(self,sTag):
		self.m_Tags.append(sTag)

class PythagorasDisplayFormVariable(object):
	def __init__(self,Name,Dictionary):
		self.m_Name = Name
		self.m_Dictionary = Dictionary
		self.m_Dictionary['Registry'] = True
	
	def GetName(self):
		return self.m_Name
	
	def SetDescription(self,Description):
		self.m_Dictionary['Description'] = Description
		
	def GetDescription(self):
		return self.m_Dictionary['Description']
		
	def SetDefault(self,Value):
		self.m_Dictionary['Default'] = Value
		
	def GetDefault(self):
		return self.m_Dictionary['Default']
		
	def SetRegistry(self,Boolean):
		self.m_Dictionary['Registry'] = Boolean
		
	def GetRegistry(self):
		return self.m_Dictionary['Registry']
	
	def SetMaxLength(self,Length):
		self.m_Dictionary['MaxLength'] = Length
		
	def GetMaxLength(self):
		return self.m_Dictionary['MaxLength']
		
	def SetPassword(self,Boolean):
		self.m_Dictionary['Password'] = Boolean
		
	def GetPassword(self):
		return self.m_Dictionary['Password']
		
	def SetHidden(self,Boolean):
		self.m_Dictionary['Hidden'] = Boolean
		
	def GetHidden(self):
		return self.m_Dictionary['Hidden']
	
	def AddEntry(self,Key,Value):
		if 'Entries' not in self.m_Dictionary:
			sError = 'Class object with name [' + self.m_Name + '] is not a ComboBox'
			raise ValueError(sError)
		self.m_Dictionary['Entries'][Key] = Value
		
	def GetValue(self):
		if 'Value' in self.m_Dictionary:
			return self.m_Dictionary['Value']
		return None
	
class PythagorasDisplayForm(object):
	def Init(self):
		self.m_Dictionary = dict()
		self.m_Dictionary['Version'] = '1.0'
		self.m_Dictionary['HTML'] = {
			'BGColor':'#aaaaaa',
			'Width':500,
			'Height':500,
			'ReplaceStrings':{}
		}
	
	def __init__(self):
		self.Init()
	
	def __enter__(self):
		self.Init()
		return self
		
	def __exit__(self,*args):
		return
	
	def SetVersion(self,Version):
		self.m_Dictionary['HTML']['Version'] = Version
	
	def SetBGColor(self,Color):
		self.m_Dictionary['HTML']['BGColor'] = Color
	
	def SetWidth(self,Width):
		self.m_Dictionary['HTML']['Width'] = Width
		
	def SetHeight(self,Height):
		self.m_Dictionary['HTML']['Height'] = Height
		
	def SetReplaceString(self,Key,Value):
		self.m_Dictionary['HTML']['ReplaceStrings'][Key] = Value
		
	def SetTitle(self,Title):
		self.SetReplaceString('<!--TITLE-->',Title)
		
	def SetSummary(self,Summary):
		self.SetReplaceString('<!--SUMMARY-->',Summary)
		
	def SetDefaultStyle(self,Style):
		self.SetReplaceString('<!--DEFAULT_STYLE-->',Style)
		
	def SetTemplate(self,Template):
		self.m_Dictionary['HTML']['Template'] = Template
		
	def AddCheckBox(self,Name,Description):
		self.m_Dictionary[Name] = dict()
		self.m_Dictionary[Name]['Type'] = 'CheckBox'
		self.m_Dictionary[Name]['Description'] = Description
		return PythagorasDisplayFormVariable(Name,self.m_Dictionary[Name])
	
	def AddText(self,Name,Description):
		self.m_Dictionary[Name] = dict()
		self.m_Dictionary[Name]['Type'] = 'Text'
		self.m_Dictionary[Name]['Description'] = Description
		return PythagorasDisplayFormVariable(Name,self.m_Dictionary[Name])
		
	def AddComboBox(self,Name,Description):
		self.m_Dictionary[Name] = dict()
		self.m_Dictionary[Name]['Type'] = 'ComboBox'
		self.m_Dictionary[Name]['Description'] = Description
		self.m_Dictionary[Name]['Entries'] = dict()
		return PythagorasDisplayFormVariable(Name,self.m_Dictionary[Name])
	
	def Display(self):
		self.m_ReturnValues = pythagoras.displayform(self.m_Dictionary)
		if self.m_ReturnValues is None:
			return False
			
		for k,v in self.m_ReturnValues.items():
			self.m_Dictionary[k]['Value'] = v
		return True
		
	def GetRegistryValues(self):
		self.m_ReturnValues = pythagoras.getregistryvalues(self.m_Dictionary)
		if self.m_ReturnValues is None:
			return False
			
		for k,v in self.m_ReturnValues.items():
			self.m_Dictionary[k]['Value'] = v
		return True
		
	def GetValue(self,Name):
		if Name in self.m_ReturnValues:
			return self.m_ReturnValues[Name]
		return None
		
	def CopyValues(self,Dictionary):
		for k,v in self.m_ReturnValues.items():
			Dictionary[k] = v
		return 

def _PythagorasCall(sFunction, Dictionary):
	ReturnDict = dict()
	dictStdOut = list()
	dictStdErr = list()
	retval =  None
	
	thismodule = sys.modules[__name__]
	method_to_call = getattr(thismodule, sFunction)
	
	StdOut = io.StringIO()
	StdErr = io.StringIO()
	with contextlib.redirect_stdout(StdOut):
		with contextlib.redirect_stderr(StdErr):
			try:
				retval = method_to_call(Dictionary)
			except:
				traceback.print_exc(file=sys.stderr)
	lstOutput = StdOut.getvalue().split('\n')
	lstError = StdErr.getvalue().split('\n')
	
	lstOutput = [x for x in lstOutput if x]
	lstError = [x for x in lstError if x]
	
	# Chop to the last 1024 lines so we don't overload our shared memory buffer	
	if len(lstOutput) > 1024:
		dictStdOut.append("** Output truncated to 1024 lines **")
		dictStdOut.extend(lstOutput[-1024:])
	else:
		dictStdOut = lstOutput[-1024:]

	if len(lstError) > 1024:
		dictStdErr.append("** Output truncated to 1024 lines **")
		dictStdErr.extend(lstError[-1024:])
	else:
		dictStdErr = lstError[-1024:]
	
	ReturnDict['Output'] = dictStdOut
	ReturnDict['Error'] = dictStdErr
	ReturnDict['Return'] = retval
	
	return ReturnDict