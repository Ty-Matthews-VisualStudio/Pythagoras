
#pragma once

#include "ViewTree.h"

class CFileViewToolBar : public CMFCToolBar
{
	virtual void OnUpdateCmdUI(CFrameWnd* /*pTarget*/, BOOL bDisableIfNoHndler)
	{
		CMFCToolBar::OnUpdateCmdUI((CFrameWnd*) GetOwner(), bDisableIfNoHndler);
	}

	virtual BOOL AllowShowOnList() const { return FALSE; }
};

const int cClosedFolderIcon = 0;
const int cOpenFolderIcon = 1;
const int cFileIcon = 2;
const int cFunctionIcon = 3;
const int cFunctionSelectedIcon = 4;
const int cBrokenFileIcon = 5;
const int cMyComputerIcon = 6;
const int cNethoodIcon = 7;
const int cHiddenIcon = 8;
#define NUM_ICONS (cHiddenIcon + 1)

class CMainFrame;

class CScriptsView : public CDockablePane
{
// Construction
public:
	CScriptsView();

	void AdjustLayout();
	void OnChangeVisualStyle();

// Attributes
protected:
	CMainFrame *m_pMain;
	CViewTree m_wndScriptTree;
	CImageList m_ScriptTreeImages;
	CFileViewToolBar m_wndToolBar;

protected:
	int m_iTreeIcons[NUM_ICONS];

// Implementation
public:
	std::vector< std::wstring > m_vLocalScriptFolders;
	_vLPScriptViewNode m_vScriptViewNodes;

	virtual ~CScriptsView();
	void BuildScriptTree();
	void LoadIcons();
#if 0
	void DeleteItemData();
	void RecursiveDelete(HTREEITEM hParent);
#endif
	HTREEITEM RecurseScripts(bool bTopLevel, std::wstring &sRemaining, LPScriptFunctionStruct lpScriptFunction, HTREEITEM hRoot);
	CTreeCtrl *GetTreeCtrl()
	{
		return static_cast<CTreeCtrl *>(&m_wndScriptTree);
	}

	void SetMainFrame(CMainFrame *pMain)
	{
		m_pMain = pMain;
		m_wndScriptTree.SetMainFrame(pMain);
	};

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnProperties();	
	afx_msg void OnPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);

	DECLARE_MESSAGE_MAP()
};

