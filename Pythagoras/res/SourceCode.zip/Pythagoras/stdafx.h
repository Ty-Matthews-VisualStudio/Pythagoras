
// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently,
// but are changed infrequently

#pragma once

#ifndef VC_EXTRALEAN
#define VC_EXTRALEAN            // Exclude rarely-used stuff from Windows headers
#endif

#include "targetver.h"

#define _ATL_CSTRING_EXPLICIT_CONSTRUCTORS      // some CString constructors will be explicit

// turns off MFC's hiding of some common and often safely ignored warning messages
#define _AFX_ALL_WARNINGS

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxinet.h>

#ifndef _AFX_NO_OLE_SUPPORT
#include <afxdtctl.h>           // MFC support for Internet Explorer 4 Common Controls
#endif
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>             // MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxcontrolbars.h>     // MFC support for ribbons and control bars
#include <afxShellListCtrl.h> 

#include <string>
#include <sstream>
#include <vector>
#include <map>
#include <iostream>
#include <filesystem>

#include <iomanip>
#include <ctime>

#include <direct.h>
#include <cstdlib> //std::system

#include <boost/regex.hpp>
#include <boost/system/error_code.hpp>
#include <boost/filesystem.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <boost/algorithm/string/replace.hpp>
#include <boost/algorithm/string/find.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/interprocess/managed_shared_memory.hpp>
#include <boost/interprocess/containers/vector.hpp>
#include <boost/interprocess/allocators/allocator.hpp>

#include "../Common/PythagorasEngineMemory.h"
#include "../Common/Structs.h"
#include "../Common/Utility.h"
#include "Unzip.h"
#include "Zip.h"
#include "OutputWnd.h"
#include "../Common/RegistryHelper.h"
#include "RegistrySettings.h"
#include "PPFileTabExplorer.h"
#include "PPFileTabRegex.h"
#include "PPFileTabDatabase.h"
#include "PSFileExplorer.h"
#include "../Common/MemBuffer.h"

//#pragma message (L_SOLUTIONDIR)
#define INCLUDECRYPTINGCODE_IFCRYPTALLOWED
#include "../zlib-1.2.11/zlib.h"
#include "../zlib-1.2.11/unzip.h"
#include "../zlib-1.2.11/zip.h"
#include "../zlib-1.2.11/crypt.h"
#define USEWIN32IOAPI
#include "../zlib-1.2.11/iowin32.h"
#pragma comment (lib,L_SOLUTIONDIR L_PLATFORM "\\zlibstat.lib")

#include <include/Python.h>
#include <afxdlgs.h>

#ifdef _UNICODE
#if defined _M_IX86
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='x86' publicKeyToken='6595b64144ccf1df' language='*'\"")
#elif defined _M_X64
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='amd64' publicKeyToken='6595b64144ccf1df' language='*'\"")
#else
#pragma comment(linker,"/manifestdependency:\"type='win32' name='Microsoft.Windows.Common-Controls' version='6.0.0.0' processorArchitecture='*' publicKeyToken='6595b64144ccf1df' language='*'\"")
#endif
#endif


