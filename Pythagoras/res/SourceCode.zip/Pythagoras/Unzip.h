#pragma once

#ifndef __UNZIP_H_
#define __UNZIP_H_

// Function throws std::exception
void UnzipFile(LPCTSTR szZipfile, LPCTSTR szOutputFolder);

#endif	// #ifndef __UNZIP_H_