#pragma once

#ifndef __ZIP_H_
#define __ZIP_H_

// Function throws std::exception
void ZipFile(LPCTSTR szZipfile, LPCTSTR szSourceFolder, _StringVector &vFiles);

#endif	// #ifndef __ZIP_H_