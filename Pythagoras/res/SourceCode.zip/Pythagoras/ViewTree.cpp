
#include "stdafx.h"
#include "ViewTree.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CViewTree

CViewTree::CViewTree()
{
}

CViewTree::~CViewTree()
{
}

BEGIN_MESSAGE_MAP(CViewTree, CTreeCtrl)	
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CViewTree message handlers

BOOL CViewTree::OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult)
{
	BOOL bRes = CTreeCtrl::OnNotify(wParam, lParam, pResult);

	NMHDR* pNMHDR = (NMHDR*)lParam;
	ASSERT(pNMHDR != NULL);

	if (pNMHDR && pNMHDR->code == TTN_SHOW && GetToolTips() != NULL)
	{
		GetToolTips()->SetWindowPos(&wndTop, -1, -1, -1, -1, SWP_NOMOVE | SWP_NOACTIVATE | SWP_NOSIZE);
	}

	return bRes;
}

void CViewTree::Clear()
{
	SetRedraw(FALSE);
	DeleteAllItems();
	SetRedraw(TRUE);
	Invalidate(FALSE);
}

#if 0
void CViewTree::OnNMDblclk(NMHDR *pNMHDR, LRESULT *pResult)
{
	// TODO: Add your control notification handler code here
	*pResult = 0;
}

void CViewTree::OnTvnSelchanged(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	HTREEITEM hNew = pNMTreeView->itemNew.hItem;
	HTREEITEM hOld = pNMTreeView->itemOld.hItem;

	if (hNew)
	{
		DWORD_PTR dwp = GetItemData(hNew);
		if (dwp != 0)
		{
			m_lpSelectedScript = reinterpret_cast< LPScriptFunctionStruct >(dwp);
			m_lstFunctions.DeleteAllItems();
			if (m_lpSelectedScript->bErrors || m_lpSelectedScript->vFunctions.size() == 0)
			{
				SetListMode(false);
				m_CompileMessage.SetTargetDevice(NULL, 0);
				m_CompileMessage.SetSel(0, -1);
				m_CompileMessage.Clear();

				if (m_lpSelectedScript->bErrors)
				{
					m_CompileMessage.ReplaceSel(m_lpSelectedScript->ssErrorMessage.str().c_str());
				}
				else
				{
					m_CompileMessage.ReplaceSel("No functions found");
				}
			}
			else
			{
				SetListMode(true);
				int i = 0;
				for (_itFunction itScript = m_lpSelectedScript->vFunctions.begin(); itScript != m_lpSelectedScript->vFunctions.end(); itScript++, i++)
				{
					LVITEM lvi;
					memset(&lvi, 0, sizeof(LVITEM));

					lvi.mask = LVIF_TEXT | LVIF_PARAM;
					lvi.iItem = i;
					lvi.iSubItem = 0;
					lvi.pszText = (LPTSTR)(LPCTSTR)((*itScript)->sFunctionName.c_str());
					lvi.lParam = i;
					int iItem = m_lstFunctions.InsertItem(&lvi);
					m_lstFunctions.SetItemText(iItem, 1, (LPTSTR)(LPCTSTR)((*itScript)->sDescription.c_str()));
				}

				// Select the first function in the script
				if (m_lstFunctions.GetItemCount() > 0)
				{
					m_lstFunctions.SetItemState(0, LVIS_SELECTED, LVIS_SELECTED);
					m_lstFunctions.SetSelectionMark(0);
					m_lstFunctions.SetFocus();
				}
			}
		}
	}
	
	*pResult = 0;
}
#endif