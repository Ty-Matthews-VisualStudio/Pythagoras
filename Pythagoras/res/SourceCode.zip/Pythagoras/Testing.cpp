// Testing.cpp : implementation file
//

#include "stdafx.h"
#include "Pythagoras.h"
#include "Testing.h"
#include "afxdialogex.h"


// Testing dialog

IMPLEMENT_DYNAMIC(Testing, CDialogEx)

Testing::Testing(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_TESTING, pParent)
{

}

Testing::~Testing()
{
}

void Testing::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(Testing, CDialogEx)
END_MESSAGE_MAP()


// Testing message handlers
