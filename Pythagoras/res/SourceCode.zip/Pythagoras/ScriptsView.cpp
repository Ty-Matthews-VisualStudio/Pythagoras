
#include "stdafx.h"
#include "mainfrm.h"
#include "ScriptsView.h"
#include "Resource.h"
#include "Pythagoras.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileView

CScriptsView::CScriptsView()
{
}

CScriptsView::~CScriptsView()
{
	EraseDataVector<_vLPScriptViewNode>(m_vScriptViewNodes);
}

BEGIN_MESSAGE_MAP(CScriptsView, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(ID_PROPERTIES, OnProperties)	
	ON_WM_PAINT()
	ON_WM_SETFOCUS()
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWorkspaceBar message handlers

int CScriptsView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	// Create view:
	const DWORD dwViewStyle = WS_CHILD | WS_VISIBLE | TVS_HASLINES | TVS_LINESATROOT | TVS_HASBUTTONS;

	if (!m_wndScriptTree.Create(dwViewStyle, rectDummy, this, IDC_TREE_SCRIPTS_VIEW))
	{
		TRACE0("Failed to create file view\n");
		return -1;      // fail to create
	}

#if 0
	// Load view images:
	m_ScriptTreeImages.Create(IDB_FILE_VIEW, 16, 0, RGB(255, 0, 255));
	m_wndScriptTree.SetImageList(&m_ScriptTreeImages, TVSIL_NORMAL);
#endif
	
	LoadIcons();

	m_wndToolBar.Create(this, AFX_DEFAULT_TOOLBAR_STYLE, IDR_EXPLORER);
	m_wndToolBar.LoadToolBar(IDR_EXPLORER, 0, 0, TRUE /* Is locked */);

	OnChangeVisualStyle();

	m_wndToolBar.SetPaneStyle(m_wndToolBar.GetPaneStyle() | CBRS_TOOLTIPS | CBRS_FLYBY);

	m_wndToolBar.SetPaneStyle(m_wndToolBar.GetPaneStyle() & ~(CBRS_GRIPPER | CBRS_SIZE_DYNAMIC | CBRS_BORDER_TOP | CBRS_BORDER_BOTTOM | CBRS_BORDER_LEFT | CBRS_BORDER_RIGHT));

	m_wndToolBar.SetOwner(this);

	// All commands will be routed via this control , not via the parent frame:
	m_wndToolBar.SetRouteCommandsViaFrame(FALSE);

	// Fill in some static tree view data (dummy code, nothing magic here)	
	AdjustLayout();

	return 0;
}

void CScriptsView::LoadIcons()
{
	int w = GetSystemMetrics(SM_CXSMICON);
	int h = GetSystemMetrics(SM_CYSMICON);
	HICON hIcon = NULL;
	int x = 0;
	int NumIcons = 0;
	m_ScriptTreeImages.Create(w, h, ILC_COLOR24, 50, 50);
	m_ScriptTreeImages.SetBkColor(GetSysColor(COLOR_WINDOW));

	NumIcons = (int)ExtractIcon(theApp.m_hInstance, _T("shell32.dll"), -1);
	for (x = 0; x < NumIcons; x++)
	{
		hIcon = ExtractIcon(theApp.m_hInstance, _T("shell32.dll"), x);
		int iAdd = m_ScriptTreeImages.Add(hIcon);
		DestroyIcon(hIcon);

		switch (x)
		{
		case 3:
			m_iTreeIcons[cClosedFolderIcon] = iAdd;
			break;
		
		case 4:
			m_iTreeIcons[cOpenFolderIcon] = iAdd;
			break;
		
		case 15:
			m_iTreeIcons[cMyComputerIcon] = iAdd;
			break;

		case 18:
			m_iTreeIcons[cNethoodIcon] = iAdd;
			break;

		case 43:
			m_iTreeIcons[cFunctionSelectedIcon] = iAdd;
			break;

		case 47:
			m_iTreeIcons[cHiddenIcon] = iAdd;			
			break;

		case 89:
			m_iTreeIcons[cFunctionIcon] = iAdd;			
			break;		

		case 271:
			m_iTreeIcons[cBrokenFileIcon] = iAdd;			
			break;

		case 284:
			m_iTreeIcons[cFileIcon] = iAdd;			
			break;		
		}
#if 0
		std::wstringstream ss;
		ss << x;
		m_wndScriptTree.InsertItem(ss.str().c_str(), iAdd, iAdd, TVI_ROOT);
#endif
	}

	m_wndScriptTree.SetImageList(&m_ScriptTreeImages, LVSIL_NORMAL);
}

void CScriptsView::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	AdjustLayout();
}

#if 0
void CScriptsView::RecursiveDelete(HTREEITEM hParent)
{
	HTREEITEM childItem;
	if( m_wndScriptTree.ItemHasChildren(hParent))
	{
		for (childItem = m_wndScriptTree.GetChildItem(childItem);
			childItem != NULL;
			childItem = m_wndScriptTree.GetNextItem(childItem, TVGN_NEXT))
		{			
			RecursiveDelete(childItem);
		}
	}
	DWORD_PTR p = m_wndScriptTree.GetItemData(hParent);
	if (p)
	{
		LPScriptViewNodeStruct lpDelete = reinterpret_cast<LPScriptViewNodeStruct>(p);
		delete lpDelete;
		m_wndScriptTree.SetItemData(hParent, NULL);
	}
}

void CScriptsView::DeleteItemData()
{
	RecursiveDelete(m_wndScriptTree.GetRootItem());
}
#endif

void CScriptsView::BuildScriptTree()
{
	_itScriptFunction itScript;
	int iPos;

	EraseDataVector<_vLPScriptViewNode>(m_vScriptViewNodes);
	m_wndScriptTree.Clear();	

	LPScriptViewNodeStruct lpNew = new ScriptViewNodeStruct;
	m_vScriptViewNodes.push_back(lpNew);
	HTREEITEM hLocal = m_wndScriptTree.InsertItem(_T("Local Scripts"), m_iTreeIcons[cMyComputerIcon], m_iTreeIcons[cMyComputerIcon], TVI_ROOT);
	lpNew->hParentNode = NULL;
	lpNew->lpScriptFunction = NULL;
	lpNew->uiLocalScriptIndex = -1;
	m_wndScriptTree.SetItemData(hLocal, (DWORD_PTR)lpNew);
	
	HTREEITEM hCommon = m_wndScriptTree.InsertItem(_T("Common Scripts"), m_iTreeIcons[cNethoodIcon], m_iTreeIcons[cNethoodIcon], TVI_ROOT);
	m_wndScriptTree.SetItemData(hCommon, NULL);

	std::string sRelative;
	for (iPos = 0, itScript = theApp.m_vScriptFunction.begin(); itScript != theApp.m_vScriptFunction.end(); itScript++, iPos++)
	{
		HTREEITEM hNode = RecurseScripts(true, (*itScript)->sRelativePath, (*itScript), ((*itScript)->ScriptType == ScriptTypeLocal ? hLocal : hCommon));
	}

	HTREEITEM hItem;
	hItem = m_wndScriptTree.GetFirstVisibleItem();
	while (hItem)
	{
		m_wndScriptTree.Expand(hItem, TVE_EXPAND);
		if (m_wndScriptTree.GetItemData(hItem) == theApp.m_RegistrySettings.m_iFunction)
		{
			m_wndScriptTree.SelectItem(hItem);
		}

		hItem = m_wndScriptTree.GetNextItem(hItem, TVGN_NEXTVISIBLE);
	}
}

HTREEITEM CScriptsView::RecurseScripts(bool bTopLevel, std::wstring &sRemaining, LPScriptFunctionStruct lpScriptFunction, HTREEITEM hRoot)
{
	_StringVector sv;	
	boost::split(sv, sRemaining, boost::is_any_of("."));
	const wchar_t *sItem = sv.at(0).c_str();
	HTREEITEM hChild = hRoot;

	if (!bTopLevel)
	{
		// See if this entry already exists at this level
		hChild = m_wndScriptTree.GetChildItem(hRoot);

		// iterate as long as new item is found
		bool bExists = false;
		while (hChild && !bExists)
		{
			CString text = m_wndScriptTree.GetItemText(hChild);
			if( !_tcsicmp(sItem, text))			
			{
				bExists = true;
			}
			else
			{
				// get the next sibling of the current item
				hChild = m_wndScriptTree.GetNextSiblingItem(hChild);
			}
		}

		if (!bExists)
		{
			LPScriptViewNodeStruct lpNew = new ScriptViewNodeStruct;
			m_vScriptViewNodes.push_back(lpNew);
			
			lpNew->hParentNode = hRoot;
			if (sv.size() == 1)
			{
				// We're a file (.py), end of the line here
				lpNew->lpScriptFunction = lpScriptFunction;
				lpNew->uiLocalScriptIndex = -1;
				lpNew->bFolder = false;

				// Set the parent node's script function pointer to our own, so they can access the path to this file.  This will get overwritten multiple
				// times when there are more than one script in a single folder, but it doesn't matter since those paths are all identical
				DWORD_PTR pParent = m_wndScriptTree.GetItemData(hRoot);
				if (pParent)
				{
					LPScriptViewNodeStruct lpParent = reinterpret_cast<LPScriptViewNodeStruct>(pParent);
					lpParent->lpChildScriptFunction = lpScriptFunction;
				}				
				
				if (!lpScriptFunction->bErrors)
				{
					if(!lpScriptFunction->bHidden)					
					{
						hChild = m_wndScriptTree.InsertItem(sItem, m_iTreeIcons[cFileIcon], m_iTreeIcons[cFileIcon], hRoot);
					}
					else
					{
						hChild = m_wndScriptTree.InsertItem(sItem, m_iTreeIcons[cHiddenIcon], m_iTreeIcons[cHiddenIcon], hRoot);
					}					
				}
				else
				{
					hChild = m_wndScriptTree.InsertItem(sItem, m_iTreeIcons[cBrokenFileIcon], m_iTreeIcons[cBrokenFileIcon], hRoot);
				}
			}
			else
			{
				// We're a folder with child items (more folders or files)
				lpNew->lpScriptFunction = NULL;
				lpNew->lpChildScriptFunction = NULL;
				lpNew->bFolder = true;
				if (lpScriptFunction->ScriptType == ScriptTypeLocal)
				{
					m_vLocalScriptFolders.push_back(sItem);
					int iIndex = m_vLocalScriptFolders.size();
					lpNew->uiLocalScriptIndex = iIndex;
				}
				else
				{
					lpNew->uiLocalScriptIndex = -1;
				}

				hChild = m_wndScriptTree.InsertItem(sItem, m_iTreeIcons[cClosedFolderIcon], m_iTreeIcons[cOpenFolderIcon], hRoot);				
			}	
			m_wndScriptTree.SetItemData(hChild, reinterpret_cast< DWORD_PTR >(lpNew));
		}
	}

	if (sv.size() > 1)
	{
		std::wstring sLeftover = sRemaining.substr(sv.at(0).size() + 1, sRemaining.size() - (sv.at(0).size() + 1));
		return RecurseScripts(false, sLeftover, lpScriptFunction, hChild);
	}
	return hChild;
}

void CScriptsView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	CTreeCtrl* pWndTree = (CTreeCtrl*) &m_wndScriptTree;
	ASSERT_VALID(pWndTree);

	if (pWnd != pWndTree)
	{
		CDockablePane::OnContextMenu(pWnd, point);
		return;
	}

	if (point != CPoint(-1, -1))
	{
		// Select clicked item:
		CPoint ptTree = point;
		pWndTree->ScreenToClient(&ptTree);

		UINT flags = 0;
		HTREEITEM hTreeItem = pWndTree->HitTest(ptTree, &flags);
		if (hTreeItem != NULL)
		{
			pWndTree->SelectItem(hTreeItem);
		}
	}

	pWndTree->SetFocus();
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EXPLORER, point.x, point.y, this, TRUE);
}

void CScriptsView::AdjustLayout()
{
	if (GetSafeHwnd() == NULL)
	{
		return;
	}

	CRect rectClient;
	GetClientRect(rectClient);

	int cyTlb = m_wndToolBar.CalcFixedLayout(FALSE, TRUE).cy;

	m_wndToolBar.SetWindowPos(NULL, rectClient.left, rectClient.top, rectClient.Width(), cyTlb, SWP_NOACTIVATE | SWP_NOZORDER);
	m_wndScriptTree.SetWindowPos(NULL, rectClient.left + 1, rectClient.top + cyTlb + 1, rectClient.Width() - 2, rectClient.Height() - cyTlb - 2, SWP_NOACTIVATE | SWP_NOZORDER);
}

void CScriptsView::OnProperties()
{
	theApp.OnAppRefreshScripts();
}

void CScriptsView::OnPaint()
{
	CPaintDC dc(this); // device context for painting

	CRect rectTree;
	m_wndScriptTree.GetWindowRect(rectTree);
	ScreenToClient(rectTree);

	rectTree.InflateRect(1, 1);
	dc.Draw3dRect(rectTree, ::GetSysColor(COLOR_3DSHADOW), ::GetSysColor(COLOR_3DSHADOW));
}

void CScriptsView::OnSetFocus(CWnd* pOldWnd)
{
	CDockablePane::OnSetFocus(pOldWnd);

	m_wndScriptTree.SetFocus();
}

void CScriptsView::OnChangeVisualStyle()
{
	m_wndToolBar.CleanUpLockedImages();
	m_wndToolBar.LoadBitmap(theApp.m_bHiColorIcons ? IDB_EXPLORER_24 : IDR_EXPLORER, 0, 0, TRUE /* Locked */);

#if 0
	m_ScriptTreeImages.DeleteImageList();

	UINT uiBmpId = theApp.m_bHiColorIcons ? IDB_FILE_VIEW_24 : IDB_FILE_VIEW;

	CBitmap bmp;
	if (!bmp.LoadBitmap(uiBmpId))
	{
		TRACE(_T("Can't load bitmap: %x\n"), uiBmpId);
		ASSERT(FALSE);
		return;
	}

	BITMAP bmpObj;
	bmp.GetBitmap(&bmpObj);

	UINT nFlags = ILC_MASK; 

	nFlags |= (theApp.m_bHiColorIcons) ? ILC_COLOR24 : ILC_COLOR4;

	m_ScriptTreeImages.Create(16, bmpObj.bmHeight, nFlags, 0, 0);
	m_ScriptTreeImages.Add(&bmp, RGB(255, 0, 255));

	m_wndScriptTree.SetImageList(&m_ScriptTreeImages, TVSIL_NORMAL);
#endif
}


