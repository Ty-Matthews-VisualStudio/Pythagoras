def MyFunc(MyList):
	for s in MyList:
		print(s)