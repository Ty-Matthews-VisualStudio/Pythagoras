#pragma once
#ifndef __PYTHON_ENGINE_MEMORY_H_
#define __PYTHON_ENGINE_MEMORY_H_

#include <boost/interprocess/managed_shared_memory.hpp>
#include <boost/container/scoped_allocator.hpp>
#include <boost/interprocess/allocators/allocator.hpp>
#include <boost/interprocess/containers/vector.hpp>
#include <boost/interprocess/containers/string.hpp>
#include <string>
#include <sstream>

using namespace boost::interprocess;

namespace PythonEngine
{
	typedef enum
	{
		ePMCompileScript = 0,
		ePMCallFunction		
	} eProcessMode;
	
	extern const char *cSharedMemoryString;
	extern const char *cFilenameArrayString;
	extern const char *cExecuteOptionsString;
	extern const char *cCompileScriptString;
	
	//Typedefs of allocators and containers
	typedef managed_shared_memory::segment_manager                       segment_manager_t;
	typedef boost::container::scoped_allocator_adaptor<allocator<void, segment_manager_t> >
		void_allocator;
	
	typedef void_allocator::rebind<int>::other                           int_allocator;
	typedef vector<int, int_allocator>                                   int_vector;

	typedef void_allocator::rebind<char>::other                          char_allocator;
	typedef basic_string<char, std::char_traits<char>, char_allocator>   char_string;

	class _SharedString
	{
	public:
		char_string	m_String;

		//Since void_allocator is convertible to any other allocator<T>, we can simplify
		//the initialization taking just one allocator for all inner containers.
		typedef void_allocator allocator_type;

		_SharedString(_SharedString const& other, const allocator_type &void_alloc)
			: m_String(other.m_String, void_alloc)
		{}
		_SharedString(const allocator_type &void_alloc)
			: m_String(void_alloc)
		{}
	};

	typedef void_allocator::rebind<_SharedString>::other    _SharedStringAllocator;
	typedef vector<_SharedString, _SharedStringAllocator>   _SharedStringVector;
	typedef vector<_SharedString, _SharedStringAllocator>::iterator _SharedStringIterator;

	class _SharedCompileScript
	{
	public:
		int m_Index;
		char_string	m_PathToFile;
		char_string m_ErrorMessage;
		_SharedStringVector m_Functions;

		//Since void_allocator is convertible to any other allocator<T>, we can simplify
		//the initialization taking just one allocator for all inner containers.
		typedef void_allocator allocator_type;

		_SharedCompileScript(_SharedCompileScript const& other, const allocator_type &void_alloc)
			: m_Index(other.m_Index), m_PathToFile(other.m_PathToFile, void_alloc), m_ErrorMessage(other.m_ErrorMessage, void_alloc), m_Functions(other.m_Functions,void_alloc)
		{}
		_SharedCompileScript(const allocator_type &void_alloc)
			: m_Index(0), m_PathToFile(void_alloc), m_ErrorMessage(void_alloc), m_Functions(void_alloc)
		{}
	};

	typedef void_allocator::rebind<_SharedCompileScript>::other    _SharedCompileScriptAllocator;
	typedef vector<_SharedCompileScript, _SharedCompileScriptAllocator>   _SharedCompileScriptVector;
	typedef vector<_SharedCompileScript, _SharedCompileScriptAllocator>::iterator _SharedCompileScriptIterator;

	class _SharedExecuteOptions
	{
	public:
		eProcessMode m_ProcessMode;
		char_string m_InspectFile;
		int m_OpenFiles;
		char_string	m_Script;
		char_string	m_Function;

		//Since void_allocator is convertible to any other allocator<T>, we can simplify
		//the initialization taking just one allocator for all inner containers.
		typedef void_allocator allocator_type;

		_SharedExecuteOptions(_SharedExecuteOptions const& other, const allocator_type &void_alloc)
			: m_ProcessMode(other.m_ProcessMode), m_InspectFile(other.m_InspectFile), m_OpenFiles(other.m_OpenFiles), m_Script(other.m_Script, void_alloc), m_Function(other.m_Script, void_alloc)
		{}
		_SharedExecuteOptions(const allocator_type &void_alloc)
			: m_ProcessMode(ePMCompileScript), m_OpenFiles(0), m_InspectFile(void_alloc), m_Script(void_alloc), m_Function(void_alloc)
		{}
	};
	typedef void_allocator::rebind<_SharedExecuteOptions>::other _SharedExecuteOptionsAllocator;

	
	void ConvertString(char_string &cs, std::string &s);
}

#endif		// #ifndef __PYTHON_ENGINE_MEMORY_H_