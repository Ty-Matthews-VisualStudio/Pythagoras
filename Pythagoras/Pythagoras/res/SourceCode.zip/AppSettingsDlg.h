#pragma once
#include "afxeditbrowsectrl.h"
#include "afxwin.h"


// AppSettingsDlg dialog

class AppSettingsDlg : public CDialogEx
{
	DECLARE_DYNAMIC(AppSettingsDlg)

public:
	AppSettingsDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~AppSettingsDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_APP_SETTINGS };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:	
	virtual BOOL OnInitDialog();
	virtual INT_PTR DoModal();
	CString m_sScriptEditor;
	CMFCEditBrowseCtrl m_ScriptEditorBrowseCtrl;
	BOOL m_bClearOutput;
	CString m_sFTPAddress;
	CString m_sFTPUsername;
	CString m_sFTPPassword;
	afx_msg void OnBnClickedButtonAppSettingsZipCommon();
	CButton m_btnZipCommon;
};
