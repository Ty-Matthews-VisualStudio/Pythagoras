// AppSettingsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Pythagoras.h"
#include "AppSettingsDlg.h"
#include "afxdialogex.h"


// AppSettingsDlg dialog

IMPLEMENT_DYNAMIC(AppSettingsDlg, CDialogEx)

AppSettingsDlg::AppSettingsDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_APP_SETTINGS, pParent)	
	, m_sScriptEditor(_T(""))
	, m_bClearOutput(FALSE)
	, m_sFTPAddress(_T(""))
	, m_sFTPUsername(_T(""))
	, m_sFTPPassword(_T(""))
{

}

AppSettingsDlg::~AppSettingsDlg()
{
}

void AppSettingsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_MFCEDITBROWSE_APP_SETTINGS_SCRIPT_EDITOR, m_sScriptEditor);
	DDX_Control(pDX, IDC_MFCEDITBROWSE_APP_SETTINGS_SCRIPT_EDITOR, m_ScriptEditorBrowseCtrl);
	DDX_Check(pDX, IDC_CHECK_APP_SETTINGS_CLEAR_OUTPUT, m_bClearOutput);
	DDX_Text(pDX, IDC_EDIT_FTP_ADDRESS, m_sFTPAddress);
	DDX_Text(pDX, IDC_EDIT_FTP_USERNAME, m_sFTPUsername);
	DDX_Text(pDX, IDC_EDIT_FTP_PASSWORD, m_sFTPPassword);
	DDX_Control(pDX, IDC_BUTTON_APP_SETTINGS_ZIP_COMMON, m_btnZipCommon);
}


BEGIN_MESSAGE_MAP(AppSettingsDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_APP_SETTINGS_ZIP_COMMON, &AppSettingsDlg::OnBnClickedButtonAppSettingsZipCommon)
END_MESSAGE_MAP()


// AppSettingsDlg message handlers


BOOL AppSettingsDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
		
	m_sScriptEditor = theApp.m_RegistrySettings.m_sScriptEditor.c_str();	
	m_ScriptEditorBrowseCtrl.EnableFileBrowseButton(_T("exe"), _T("Executable files|*.exe||"));

	m_bClearOutput = theApp.m_RegistrySettings.m_iClearOutput == 1 ? true : false;
	m_sFTPAddress = theApp.m_RegistrySettings.m_sFTPAddress.c_str();
	m_sFTPUsername = theApp.m_RegistrySettings.m_sFTPUser.c_str();
	m_sFTPPassword = theApp.m_RegistrySettings.m_sFTPPassword.c_str();

	if (!theApp.AllowAdmin())
	{
		m_btnZipCommon.ShowWindow(SW_HIDE);
	}
	//m_btnZipCommon.EnableWindow(theApp.AllowAdmin());
	
	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // EXCEPTION: OCX Property Pages should return FALSE
}


INT_PTR AppSettingsDlg::DoModal()
{
	INT_PTR iReturn = CDialogEx::DoModal();
	if (iReturn == IDOK)
	{		
		theApp.m_RegistrySettings.m_sScriptEditor = m_sScriptEditor;
		theApp.m_RegistrySettings.m_iClearOutput = m_bClearOutput ? 1 : 0;
		theApp.m_RegistrySettings.m_sFTPAddress = m_sFTPAddress;
		theApp.m_RegistrySettings.m_sFTPUser = m_sFTPUsername;
		theApp.m_RegistrySettings.m_sFTPPassword = m_sFTPPassword;
	}
	return iReturn;
}


void AppSettingsDlg::OnBnClickedButtonAppSettingsZipCommon()
{
	theApp.UploadCommonFiles();
}
