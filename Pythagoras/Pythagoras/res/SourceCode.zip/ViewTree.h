
#pragma once

/////////////////////////////////////////////////////////////////////////////
// CViewTree window

class CMainFrame;

class CViewTree : public CTreeCtrl
{
private:
	CMainFrame *m_pMain;

// Construction
public:
	CViewTree();
	void SetMainFrame(CMainFrame *pMain)
	{
		m_pMain = pMain;
	};

// Overrides
protected:
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);

// Implementation
public:
	virtual ~CViewTree();
	void Clear();

protected:
	DECLARE_MESSAGE_MAP()
public:	
};
