#include "stdafx.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <fcntl.h>
#include <direct.h>
#include <io.h>
#include "Pythagoras.h"


#define CASESENSITIVITY (0)
#define WRITEBUFFERSIZE (16384)
#define MAXFILENAME (256)

void do_extract_currentfile(unzFile uf, LPCTSTR szOutputFolder);
void do_extract(unzFile uf, LPCTSTR szOutputFolder);
void throw_exception(int err, LPCTSTR szMessage);



void throw_exception(int err, LPCTSTR szMessage)
{
	std::wstringstream ssFormat;
	ssFormat << _T("ZLIB Exception: [Message] ") << szMessage << _T(" [Code] ") << err;
	std::string sFormat;
	sFormat = CW2A(ssFormat.str().c_str());
	throw std::exception(sFormat.c_str());
}

void change_file_date(const char *filename, uLong dosdate, tm_unz tmu_date)
{
	HANDLE hFile;
	FILETIME ftm, ftLocal, ftCreate, ftLastAcc, ftLastWrite;

	hFile = CreateFileA(filename, GENERIC_READ | GENERIC_WRITE,
		0, NULL, OPEN_EXISTING, 0, NULL);
	GetFileTime(hFile, &ftCreate, &ftLastAcc, &ftLastWrite);
	DosDateTimeToFileTime((WORD)(dosdate >> 16), (WORD)dosdate, &ftLocal);
	LocalFileTimeToFileTime(&ftLocal, &ftm);
	SetFileTime(hFile, &ftm, &ftLastAcc, &ftm);
	CloseHandle(hFile);
}

int makedir(char *newdir)
{
	const SECURITY_ATTRIBUTES *psa = NULL;
	std::wstring sPath;
	sPath = CA2W(newdir);
	int retval = SHCreateDirectoryEx(NULL, sPath.c_str(), psa);
	if (retval == ERROR_SUCCESS || retval == ERROR_FILE_EXISTS || retval == ERROR_ALREADY_EXISTS)
	{
		return 1;
	}
	return 0;
}

#if 0
int do_list(unzFile uf) 
{
	uLong i;
	unz_global_info64 gi;
	int err;
	std::wstringstream ssOutput;

	err = unzGetGlobalInfo64(uf, &gi);
	if (err != UNZ_OK)
	{
		ssOutput << _T("Error ") << err << _T(" with zipfile in unzGetGlobalInfo");
		theApp.AddToOutput(eStandardOutput, ssOutput.str().c_str(), true);
		return 0;
	}
	theApp.AddToOutput(eStandardOutput, _T("Length|Method|Size|Ratio|Date|Time|CRC-32|Name"), true);
	for (i = 0; i<gi.number_entry; i++)
	{
		char filename_inzip[256];
		unz_file_info64 file_info;
		uLong ratio = 0;
		std::wstring sMethod;
		char charCrypt = ' ';
		ssOutput.str(_T(""));
		err = unzGetCurrentFileInfo64(uf, &file_info, filename_inzip, sizeof(filename_inzip), NULL, 0, NULL, 0);
		if (err != UNZ_OK)
		{			
			ssOutput << _T("Error ") << err << _T(" with zipfile in unzGetCurrentFileInfo");
			theApp.AddToOutput(eStandardOutput, ssOutput.str().c_str(), true);
			break;
		}
		if (file_info.uncompressed_size>0)
			ratio = (uLong)((file_info.compressed_size * 100) / file_info.uncompressed_size);

		/* display a '*' if the file is crypted */
		if ((file_info.flag & 1) != 0)
			charCrypt = '*';

		if (file_info.compression_method == 0)
			sMethod = _T("Stored");
		else
			if (file_info.compression_method == Z_DEFLATED)
			{
				uInt iLevel = (uInt)((file_info.flag & 0x6) / 2);
				if (iLevel == 0)
					sMethod = _T("Z_DEFLATED:N");
				else if (iLevel == 1)
					sMethod = _T("Z_DEFLATED:X");
				else if ((iLevel == 2) || (iLevel == 3))
					sMethod = _T("Z_DEFLATED:F"); /* 2:fast , 3 : extra fast*/
			}
			else
				if (file_info.compression_method == Z_BZIP2ED)
				{
					sMethod = _T("Z_BZIP2ED");
				}
				else
					sMethod = _T("Unknown");

		ssOutput << file_info.uncompressed_size << _T("|");
		ssOutput << sMethod.c_str() << charCrypt << _T("|");
		ssOutput << file_info.compressed_size << _T("|");
		ssOutput << ratio << _T("|");
		ssOutput << (uLong)file_info.tmu_date.tm_mon + 1 << _T("-");
		ssOutput << (uLong)file_info.tmu_date.tm_mday << _T("-");
		ssOutput << (uLong)file_info.tmu_date.tm_year % 100 << _T("|");
		ssOutput << (uLong)file_info.tmu_date.tm_hour << _T(":");
		ssOutput << (uLong)file_info.tmu_date.tm_min << _T("|");
		ssOutput << (uLong)file_info.crc << _T("|");
		ssOutput << filename_inzip;
		theApp.AddToOutput(eStandardOutput, ssOutput.str().c_str(), true);
				
		if ((i + 1)<gi.number_entry)
		{
			err = unzGoToNextFile(uf);
			if (err != UNZ_OK)
			{
				ssOutput.str(_T(""));
				ssOutput << _T("Error ") << err << _T(" with zipfile in unzGoToNextFile");
				theApp.AddToOutput(eStandardOutput, ssOutput.str().c_str(), true);				
				break;
			}
		}
	}

	return 0;
}
#endif

#ifdef WIN32
// Function throws std::exception
void do_extract_currentfile(unzFile uf, LPCTSTR szOutputFolder)
{
	char filename_inzip[_MAX_PATH];
	char* filename_withoutpath = NULL;
	char* p = NULL;
	int err = UNZ_OK;
	FILE *fout = NULL;
	errno_t ferr;
	static CMemBuffer Buffer;
	LPBYTE pbyBuffer = NULL;
	std::wstringstream ssLocalFile;
	std::wstringstream ssLocalFolder;
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	const SECURITY_ATTRIBUTES *psa = NULL;

	//unz_file_info64 file_info;
	unz_file_info file_info;
	uLong ratio = 0;
	//err = unzGetCurrentFileInfo64(uf, &file_info, filename_inzip, sizeof(filename_inzip), NULL, 0, NULL, 0);
	err = unzGetCurrentFileInfo(uf, &file_info, filename_inzip, sizeof(filename_inzip), NULL, 0, NULL, 0);

	if (err != UNZ_OK)
	{
		throw_exception(err, _T("Failed on call to unzGetCurrentFileInfo()"));
	}

	bool bFile = true;
	pbyBuffer = Buffer.GetBuffer(WRITEBUFFERSIZE);
	p = filename_withoutpath = filename_inzip;
	std::wstring ws;
	std::wstring::reverse_iterator rit;

	ws = CA2W(filename_inzip);
	rit = ws.rbegin();
	if ((*rit) == '/' || (*rit) == '\\')
	{
		bFile = false;
	}
	ssLocalFile << szOutputFolder << _T("\\") << ws.c_str();

	// Have to make the local folder in case it doesn't exist			
	_wsplitpath_s(ssLocalFile.str().c_str(), drive, _MAX_DRIVE, dir, _MAX_DIR, NULL, 0, NULL, 0);
	ssLocalFolder << drive << dir;

	int retval = SHCreateDirectoryEx(NULL, ssLocalFolder.str().c_str(), psa);
	if (bFile && (retval == ERROR_SUCCESS || retval == ERROR_FILE_EXISTS || retval == ERROR_ALREADY_EXISTS))
	{
		err = unzOpenCurrentFilePassword(uf, NULL);
		if (err != UNZ_OK)
		{
			throw_exception(err, _T("Failed on call to unzOpenCurrentFilePassword()"));
		}
		// Read first chunk, then try to open the file
		err = unzReadCurrentFile(uf, pbyBuffer, WRITEBUFFERSIZE);
		if (err<0)
		{
			throw_exception(err, _T("Failed on call to unzReadCurrentFile()"));
		}

		if (err > 0)
		{
			ferr = _wfopen_s(&fout, ssLocalFile.str().c_str(), _T("wb"));
			if (ferr != 0)
			{
				throw_exception(ferr, _T("Failed to open local file"));
			}
			do
			{
				if (fwrite(pbyBuffer, 1, err, fout) != err)
				{
					throw_exception(0, _T("Failed to write data to file"));
				}

				// Read next chunk
				err = unzReadCurrentFile(uf, pbyBuffer, WRITEBUFFERSIZE);
				if (err<0)
				{
					throw_exception(err, _T("Failed on call to unzReadCurrentFile()"));
				}
			} while (err>0);
			fclose(fout);

			if (err == 0)
			{
				std::string sFileName;
				sFileName = CW2A(ssLocalFile.str().c_str());
				change_file_date(sFileName.c_str(), file_info.dosDate,
					file_info.tmu_date);
			}
		}
		err = unzCloseCurrentFile(uf);
		if (err != UNZ_OK)
		{
			throw_exception(err, _T("Failed on call to unzCloseCurrentFile()"));
		}
	}
}
void do_extract(unzFile uf, LPCTSTR szOutputFolder)
{
	uLong i;
	//unz_global_info64 gi;
	unz_global_info gi;
	int err;
	FILE* fout = NULL;

	//err = unzGetGlobalInfo64(uf, &gi);
	err = unzGetGlobalInfo(uf, &gi);
	if (err != UNZ_OK)
	{
		throw_exception(err, _T("Failed on call to unzGetGlobalInfo()"));
	}

	for (i = 0; i<gi.number_entry; i++)
	{
		do_extract_currentfile(uf, szOutputFolder);

		if ((i + 1)<gi.number_entry)
		{
			err = unzGoToNextFile(uf);
			if (err != UNZ_OK)
			{
				throw_exception(err, _T("Failed on call to unzGoToNextFile()"));
				break;
			}
		}
	}
}

void UnzipFile(LPCTSTR szZipfile, LPCTSTR szOutputFolder)
{
	unzFile uf = NULL;
	zlib_filefunc_def ffunc;
	//zlib_filefunc64_def ffunc;
	std::string sZipFile;
	sZipFile = CW2A(szZipfile);

	fill_win32_filefunc(&ffunc);
	//fill_win32_filefunc64A(&ffunc);	

	uf = unzOpen2(sZipFile.c_str(), &ffunc);
	//uf = unzOpen2_64(sZipFile.c_str(), &ffunc);

	if (uf)
	{
		do_extract(uf, szOutputFolder);
		unzClose(uf);
	}
}
#else

// Function throws std::exception
void do_extract_currentfile(unzFile uf, LPCTSTR szOutputFolder)
{
	char filename_inzip[_MAX_PATH];
	char* filename_withoutpath = NULL;
	char* p = NULL;
	int err = UNZ_OK;
	FILE *fout = NULL;
	errno_t ferr;
	static CMemBuffer Buffer;
	LPBYTE pbyBuffer = NULL;
	std::wstringstream ssLocalFile;
	std::wstringstream ssLocalFolder;
	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	const SECURITY_ATTRIBUTES *psa = NULL;

	unz_file_info64 file_info;
	uLong ratio = 0;
	err = unzGetCurrentFileInfo64(uf, &file_info, filename_inzip, sizeof(filename_inzip), NULL, 0, NULL, 0);

	if (err != UNZ_OK)
	{
		throw_exception(err, _T("Failed on call to unzGetCurrentFileInfo()"));
	}

	bool bFile = true;
	pbyBuffer = Buffer.GetBuffer(WRITEBUFFERSIZE);
	p = filename_withoutpath = filename_inzip;
	std::wstring ws;
	std::wstring::reverse_iterator rit;

	ws = CA2W(filename_inzip);
	rit = ws.rbegin();
	if ((*rit) == '/' || (*rit) == '\\')
	{
		bFile = false;
	}
	ssLocalFile << szOutputFolder << _T("\\") << ws.c_str();

	// Have to make the local folder in case it doesn't exist			
	_wsplitpath_s(ssLocalFile.str().c_str(), drive, _MAX_DRIVE, dir, _MAX_DIR, NULL, 0, NULL, 0);
	ssLocalFolder << drive << dir;

	int retval = SHCreateDirectoryEx(NULL, ssLocalFolder.str().c_str(), psa);
	if (bFile && (retval == ERROR_SUCCESS || retval == ERROR_FILE_EXISTS || retval == ERROR_ALREADY_EXISTS))
	{
		err = unzOpenCurrentFilePassword(uf, NULL);
		if (err != UNZ_OK)
		{
			throw_exception(err, _T("Failed on call to unzOpenCurrentFilePassword()"));
		}
		// Read first chunk, then try to open the file
		err = unzReadCurrentFile(uf, pbyBuffer, WRITEBUFFERSIZE);
		if (err<0)
		{
			throw_exception(err, _T("Failed on call to unzReadCurrentFile()"));
		}

		if (err > 0)
		{
			ferr = _wfopen_s(&fout, ssLocalFile.str().c_str(), _T("wb"));
			if (ferr != 0)
			{
				throw_exception(ferr, _T("Failed to open local file"));
			}
			do
			{
				if (fwrite(pbyBuffer, 1, err, fout) != err)
				{
					throw_exception(0, _T("Failed to write data to file"));
				}

				// Read next chunk
				err = unzReadCurrentFile(uf, pbyBuffer, WRITEBUFFERSIZE);
				if (err<0)
				{
					throw_exception(err, _T("Failed on call to unzReadCurrentFile()"));
				}
			} while (err>0);
			fclose(fout);

			if (err == 0)
			{
				std::string sFileName;
				sFileName = CW2A(ssLocalFile.str().c_str());
				change_file_date(sFileName.c_str(), file_info.dosDate,
					file_info.tmu_date);
			}
		}
		err = unzCloseCurrentFile(uf);
		if (err != UNZ_OK)
		{
			throw_exception(err, _T("Failed on call to unzCloseCurrentFile()"));
		}
	}
}

void do_extract(unzFile uf, LPCTSTR szOutputFolder)
{
	uLong i;
	unz_global_info64 gi;
	int err;
	FILE* fout = NULL;

	err = unzGetGlobalInfo64(uf, &gi);
	if (err != UNZ_OK)
	{
		throw_exception(err, _T("Failed on call to unzGetGlobalInfo64()"));
	}

	for (i = 0; i<gi.number_entry; i++)
	{
		do_extract_currentfile(uf, szOutputFolder);

		if ((i + 1)<gi.number_entry)
		{
			err = unzGoToNextFile(uf);
			if (err != UNZ_OK)
			{
				throw_exception(err, _T("Failed on call to unzGoToNextFile()"));
				break;
			}
		}
	}
}

void UnzipFile(LPCTSTR szZipfile, LPCTSTR szOutputFolder)
{
	unzFile uf = NULL;
	zlib_filefunc64_def ffunc;
	std::string sZipFile;
	sZipFile = CW2A(szZipfile);

	fill_win32_filefunc64A(&ffunc);
	uf = unzOpen2_64(sZipFile.c_str(), &ffunc);

	if (uf)
	{
		do_extract(uf, szOutputFolder);
		unzClose(uf);
	}
}
#endif